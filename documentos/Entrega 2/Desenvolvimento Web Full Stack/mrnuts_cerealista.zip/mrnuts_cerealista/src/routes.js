import { Router } from 'express'
import upload from './uploadConfig.js'
import { verifyTokenMiddleware } from './middlewares/authMiddleware.js'

import {
    registerADM, loginADM, logoutADM, forgotPasswordADM
} from './controllers/authADMController.js'
import {
    getUsersADM, getADMByRA, createUserADM, updateUserADM, deleteUserADM,
    profileADM, updateMeADM
} from './controllers/ADMController.js'

import {
    registerClient, loginClient, logoutClient, forgotPasswordClient
} from './controllers/authClienteController.js'
import {
    getUsersClient, getClientByID, createUserClient, updateUserClient, deleteUserClient,
    profileClient, updateMeClient
} from './controllers/ClienteController.js'

import {
    registerFornecedor, loginFornecedor, logoutFornecedor, forgotPasswordFornecedor
} from './controllers/authFornecedorController.js'
import {
    getUsersFornecedor, getFornecedorByID, createUserFornecedor, updateUserFornecedor, deleteUserFornecedor,
    profileFornecedor, updateMeFornecedor
} from './controllers/FornecedorController.js'

import {
    getProdutos, getProdutoById, createProduto, updateProduto, deleteProduto
} from './controllers/ProdutoController.js'

const r = Router()

// ── AUTH SEM AUTENTICAÇÃO ────────────────────────────
r.post('/auth/register/adm',        registerADM)
r.post('/auth/login/adm',           loginADM)
r.post('/auth/forgot-password/adm', forgotPasswordADM)

r.post('/auth/register/cliente',        registerClient)
r.post('/auth/login/cliente',           loginClient)
r.post('/auth/forgot-password/cliente', forgotPasswordClient)

r.post('/auth/register/fornecedor',        registerFornecedor)
r.post('/auth/login/fornecedor',           loginFornecedor)
r.post('/auth/forgot-password/fornecedor', forgotPasswordFornecedor)

// ── AUTH COM AUTENTICAÇÃO ────────────────────────────
r.post('/auth/logout/adm',        verifyTokenMiddleware, logoutADM)
r.post('/auth/logout/cliente',    verifyTokenMiddleware, logoutClient)
r.post('/auth/logout/fornecedor', verifyTokenMiddleware, logoutFornecedor)

// ── PERFIL DO USUÁRIO LOGADO ─────────────────────────
r.get('/adm/profile',      verifyTokenMiddleware, profileADM)
r.put('/adm/me',           verifyTokenMiddleware, updateMeADM)

r.get('/cliente/profile',  verifyTokenMiddleware, profileClient)
r.put('/cliente/me',       verifyTokenMiddleware, updateMeClient)

r.get('/fornecedor/profile', verifyTokenMiddleware, profileFornecedor)
r.put('/fornecedor/me',      verifyTokenMiddleware, updateMeFornecedor)

// ── CRUD ADM ─────────────────────────────────────────
r.get('/adm',              getUsersADM)
r.get('/adm/:ra',          verifyTokenMiddleware, getADMByRA)
r.post('/adm',             verifyTokenMiddleware, upload.single('image'), createUserADM)
r.put('/adm/:ra',          verifyTokenMiddleware, upload.single('image'), updateUserADM)
r.delete('/adm/:ra',       verifyTokenMiddleware, deleteUserADM)

// ── CRUD CLIENTE ──────────────────────────────────────
r.get('/cliente',          getUsersClient)
r.get('/cliente/:idc',     verifyTokenMiddleware, getClientByID)
r.post('/cliente',         verifyTokenMiddleware, upload.single('image'), createUserClient)
r.put('/cliente/:idc',     verifyTokenMiddleware, upload.single('image'), updateUserClient)
r.delete('/cliente/:idc',  verifyTokenMiddleware, deleteUserClient)

// ── CRUD FORNECEDOR ───────────────────────────────────
r.get('/fornecedor',       getUsersFornecedor)
r.get('/fornecedor/:idf',  verifyTokenMiddleware, getFornecedorByID)
r.post('/fornecedor',      verifyTokenMiddleware, upload.single('image'), createUserFornecedor)
r.put('/fornecedor/:idf',  verifyTokenMiddleware, upload.single('image'), updateUserFornecedor)
r.delete('/fornecedor/:idf', verifyTokenMiddleware, deleteUserFornecedor)

// ── CRUD PRODUTOS ─────────────────────────────────────
// GET aberto (o frontend carrega produtos sem login)
r.get('/produtos',          getProdutos)
r.get('/produtos/:id',      getProdutoById)
// criação/edição exige autenticação de fornecedor
r.post('/produtos',         verifyTokenMiddleware, upload.single('image'), createProduto)
r.put('/produtos/:id',      verifyTokenMiddleware, upload.single('image'), updateProduto)
r.delete('/produtos/:id',   verifyTokenMiddleware, deleteProduto)

export default r

import { pool } from '../db.js'
import fs from 'fs'
import bcrypt from 'bcrypt'
import path from 'path'

// Criar Usuário Fornecedor
export async function createUserFornecedor(req, res) {
    const { name, cnpj, email } = req.body
    if (!name || !cnpj || !email) {
        if (req.file) fs.unlink(req.file.path, () => {})
        return res.status(400).json({ error: 'Nome, CNPJ e Email são obrigatórios' })
    }
    const imgPath = req.file ? 'uploads/' + path.basename(req.file.path) : null
    try {
        const [result] = await pool.query(
            'INSERT INTO fornecedor (name, cnpj, email, img) VALUES (?,?,?,?)',
            [name, cnpj, email, imgPath]
        )
        res.status(201).json({ idf: result.insertId, img: imgPath })
    } catch (err) {
        if (req.file) fs.unlink(req.file.path, () => {})
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Fornecedor já cadastrado' })
        res.status(500).json({ error: 'Erro ao criar Fornecedor' })
    }
}

// Listar Todos — coluna correta: id_fornecedor (aliasado como idf para o frontend)
export async function getUsersFornecedor(_, res) {
    try {
        const [rows] = await pool.query(
            'SELECT id_fornecedor AS idf, name, cnpj, email, img, created_at FROM fornecedor ORDER BY id_fornecedor DESC'
        )
        res.json(rows)
    } catch {
        res.status(500).json({ error: 'Erro ao listar Fornecedor' })
    }
}

// Buscar por IDF
export async function getFornecedorByID(req, res) {
    const { idf } = req.params
    try {
        const [rows] = await pool.query(
            'SELECT id_fornecedor AS idf, name, cnpj, email, img, created_at FROM fornecedor WHERE id_fornecedor = ?',
            [idf]
        )
        if (rows.length === 0)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        res.json(rows[0])
    } catch {
        res.status(500).json({ error: 'Erro ao Buscar Fornecedor' })
    }
}

// PUT (Alterar)
export async function updateUserFornecedor(req, res) {
    const { idf } = req.params
    const { name, cnpj, email } = req.body
    if (!name || !email) {
        return res.status(400).json({ error: 'Nome e email são obrigatórios!' })
    }
    try {
        const [rows] = await pool.query('SELECT * FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (rows.length === 0)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        const oldImg = rows[0].img
        const newImg = req.file ? 'uploads/' + path.basename(req.file.path) : oldImg
        const [result] = await pool.query(
            'UPDATE fornecedor SET name = ?, cnpj = ?, email = ?, img = ? WHERE id_fornecedor = ?',
            [name, cnpj || rows[0].cnpj, email, newImg, idf]
        )
        if (result.affectedRows === 0)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        if (req.file && oldImg)
            fs.unlink(oldImg, err => { if (err) console.warn('Remover:', err) })
        const [updated] = await pool.query(
            'SELECT id_fornecedor AS idf, name, cnpj, email, img, created_at FROM fornecedor WHERE id_fornecedor = ?',
            [idf]
        )
        res.json(updated[0])
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Email já cadastrado' })
        res.status(500).json({ error: 'Erro ao atualizar Fornecedor' })
    }
}

// DELETE
export async function deleteUserFornecedor(req, res) {
    const { idf } = req.params
    if (parseInt(idf, 10) !== req.fornecedor?.idf)
        return res.status(403).json({ error: 'Você só pode deletar a própria conta' })
    try {
        const [rows] = await pool.query('SELECT * FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (rows.length === 0)
            return res.status(404).json({ error: 'Usuário não encontrado!' })
        const imgPath = rows[0].img
        await pool.query('DELETE FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (imgPath) fs.unlink(imgPath, err => { if (err) console.warn('Remover:', err) })
        res.json({ message: 'Usuário excluído com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao excluir usuário' })
    }
}

// Perfil do Usuário Logado
export async function profileFornecedor(req, res) {
    try {
        const [rows] = await pool.query(
            'SELECT id_fornecedor AS idf, name, cnpj, email, img, created_at FROM fornecedor WHERE id_fornecedor = ?',
            [req.fornecedor?.idf]
        )
        if (!rows.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        res.json(rows[0])
    } catch {
        res.status(500).json({ error: 'Erro ao buscar o perfil' })
    }
}

// UpdateMe
export async function updateMeFornecedor(req, res) {
    const { name, currentPassword, newPassword } = req.body
    if (!name && !newPassword)
        return res.status(400).json({ error: 'Envie ao menos o name ou newPassword' })
    try {
        const [rows] = await pool.query(
            'SELECT * FROM fornecedor WHERE id_fornecedor = ?',
            [req.fornecedor?.idf]
        )
        if (!rows.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        const fornecedor = rows[0]
        const updates = [], params = []
        if (name) { updates.push('name=?'); params.push(name) }
        if (newPassword) {
            if (!currentPassword)
                return res.status(400).json({ error: 'Envie currentPassword para trocar a senha' })
            const match = await bcrypt.compare(currentPassword, fornecedor.password)
            if (!match)
                return res.status(401).json({ error: 'Senha Atual Incorreta' })
            const hash = await bcrypt.hash(newPassword, 10)
            updates.push('password=?')
            params.push(hash)
        }
        params.push(req.fornecedor?.idf)
        await pool.query(`UPDATE fornecedor SET ${updates.join(', ')} WHERE id_fornecedor = ?`, params)
        const [fresh] = await pool.query(
            'SELECT id_fornecedor AS idf, name, cnpj, email, img, created_at FROM fornecedor WHERE id_fornecedor = ?',
            [req.fornecedor?.idf]
        )
        res.json(fresh[0])
    } catch (err) {
        console.log('ERRO', err.message)
        res.status(500).json({ error: 'Erro ao atualizar' })
    }
}

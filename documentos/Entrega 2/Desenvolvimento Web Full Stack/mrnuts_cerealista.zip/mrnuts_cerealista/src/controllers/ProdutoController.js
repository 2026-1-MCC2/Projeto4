import { pool } from '../db.js'
import fs from 'fs'
import path from 'path'

// Listar todos os produtos (rota aberta)
export async function getProdutos(req, res) {
    try {
        const [rows] = await pool.query(
            'SELECT * FROM produtos ORDER BY created_at DESC'
        )
        res.json(rows)
    } catch {
        res.status(500).json({ error: 'Erro ao listar produtos' })
    }
}

// Buscar produto por ID
export async function getProdutoById(req, res) {
    const { id } = req.params
    try {
        const [rows] = await pool.query(
            'SELECT * FROM produtos WHERE Cod_produto = ?', [id]
        )
        if (!rows.length)
            return res.status(404).json({ error: 'Produto não encontrado' })
        res.json(rows[0])
    } catch {
        res.status(500).json({ error: 'Erro ao buscar produto' })
    }
}

// Criar produto (fornecedor autenticado)
export async function createProduto(req, res) {
    // id_fornecedor vem do token (req.fornecedor.idf)
    const id_fornecedor = req.fornecedor?.idf ?? req.user?.idf
    if (!id_fornecedor)
        return res.status(403).json({ error: 'Apenas fornecedores podem publicar produtos' })

    const { Titulo, Preco, Descricao, Categoria } = req.body
    if (!Titulo || !Preco || !Categoria)
        return res.status(400).json({ error: 'Título, preço e categoria são obrigatórios' })

    const imgPath = req.file ? 'uploads/' + path.basename(req.file.path) : null
    try {
        const [result] = await pool.query(
            'INSERT INTO produtos (Titulo, Preco, Descricao, Categoria, img, id_fornecedor) VALUES (?,?,?,?,?,?)',
            [Titulo, Preco, Descricao || null, Categoria, imgPath, id_fornecedor]
        )
        res.status(201).json({ Cod_produto: result.insertId, Titulo, Preco, Categoria, img: imgPath })
    } catch (err) {
        if (req.file) fs.unlink(req.file.path, () => {})
        res.status(500).json({ error: 'Erro ao criar produto' })
    }
}

// Atualizar produto (apenas o próprio fornecedor)
export async function updateProduto(req, res) {
    const { id } = req.params
    const id_fornecedor = req.fornecedor?.idf ?? req.user?.idf
    try {
        const [rows] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        if (!rows.length)
            return res.status(404).json({ error: 'Produto não encontrado' })
        if (rows[0].id_fornecedor !== id_fornecedor)
            return res.status(403).json({ error: 'Você só pode editar seus próprios produtos' })

        const { Titulo, Preco, Descricao, Categoria } = req.body
        const oldImg = rows[0].img
        const newImg = req.file ? 'uploads/' + path.basename(req.file.path) : oldImg

        await pool.query(
            'UPDATE produtos SET Titulo=?, Preco=?, Descricao=?, Categoria=?, img=? WHERE Cod_produto=?',
            [Titulo || rows[0].Titulo, Preco || rows[0].Preco, Descricao ?? rows[0].Descricao, Categoria || rows[0].Categoria, newImg, id]
        )
        if (req.file && oldImg) fs.unlink(oldImg, () => {})
        const [updated] = await pool.query('SELECT * FROM produtos WHERE Cod_produto=?', [id])
        res.json(updated[0])
    } catch {
        res.status(500).json({ error: 'Erro ao atualizar produto' })
    }
}

// Deletar produto (apenas o próprio fornecedor ou ADM)
export async function deleteProduto(req, res) {
    const { id } = req.params
    const id_fornecedor = req.fornecedor?.idf ?? req.user?.idf
    const isAdm = req.adm?.ra !== undefined
    try {
        const [rows] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        if (!rows.length)
            return res.status(404).json({ error: 'Produto não encontrado' })
        if (!isAdm && rows[0].id_fornecedor !== id_fornecedor)
            return res.status(403).json({ error: 'Você só pode remover seus próprios produtos' })

        const imgPath = rows[0].img
        await pool.query('DELETE FROM produtos WHERE Cod_produto = ?', [id])
        if (imgPath) fs.unlink(imgPath, () => {})
        res.json({ message: 'Produto removido com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao deletar produto' })
    }
}

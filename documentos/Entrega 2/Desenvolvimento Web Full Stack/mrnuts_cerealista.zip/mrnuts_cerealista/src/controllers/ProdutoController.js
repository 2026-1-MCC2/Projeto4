import { pool } from '../db.js'
import fs from 'fs'
import path from 'path'

// Listar todos os produtos (com nome do fornecedor)
export async function getProdutos(_, res) {
    try {
        const [rows] = await pool.query(`
            SELECT p.Cod_produto, p.Titulo, p.Preco, p.Descricao, p.Categoria, p.img,
                   p.id_fornecedor, f.name AS fornecedor_nome, p.created_at
            FROM produtos p
            JOIN fornecedor f ON f.id_fornecedor = p.id_fornecedor
            ORDER BY p.Cod_produto DESC
        `)
        res.json(rows)
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro ao listar produtos' })
    }
}

// Buscar produto por ID
export async function getProdutoById(req, res) {
    const { id } = req.params
    try {
        const [rows] = await pool.query(`
            SELECT p.Cod_produto, p.Titulo, p.Preco, p.Descricao, p.Categoria, p.img,
                   p.id_fornecedor, f.name AS fornecedor_nome, p.created_at
            FROM produtos p
            JOIN fornecedor f ON f.id_fornecedor = p.id_fornecedor
            WHERE p.Cod_produto = ?
        `, [id])
        if (!rows.length)
            return res.status(404).json({ error: 'Produto não encontrado' })
        res.json(rows[0])
    } catch {
        res.status(500).json({ error: 'Erro ao buscar produto' })
    }
}

// Criar produto — só fornecedor autenticado
export async function createProduto(req, res) {
    // req.fornecedor é populado pelo middleware para fornecedores
    if (!req.fornecedor)
        return res.status(403).json({ error: 'Apenas fornecedores podem cadastrar produtos' })

    const { Titulo, Preco, Descricao, Categoria } = req.body
    if (!Titulo || !Preco)
        return res.status(400).json({ error: 'Título e Preço são obrigatórios' })

    const imgPath = req.file ? 'uploads/' + path.basename(req.file.path) : null
    try {
        const [result] = await pool.query(
            'INSERT INTO produtos (Titulo, Preco, Descricao, Categoria, img, id_fornecedor) VALUES (?,?,?,?,?,?)',
            [Titulo, Preco, Descricao || null, Categoria || null, imgPath, req.fornecedor.idf]
        )
        res.status(201).json({ Cod_produto: result.insertId, Titulo, Preco, imgPath })
    } catch (err) {
        if (req.file) fs.unlink(req.file.path, () => {})
        res.status(500).json({ error: 'Erro ao criar produto' })
    }
}

// Atualizar produto
export async function updateProduto(req, res) {
    const { id } = req.params
    const { Titulo, Preco, Descricao, Categoria } = req.body
    try {
        const [rows] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        if (!rows.length)
            return res.status(404).json({ error: 'Produto não encontrado' })

        // Apenas o fornecedor dono pode editar
        if (req.fornecedor && rows[0].id_fornecedor !== req.fornecedor.idf)
            return res.status(403).json({ error: 'Sem permissão para editar este produto' })

        const oldImg = rows[0].img
        const newImg = req.file ? 'uploads/' + path.basename(req.file.path) : oldImg

        await pool.query(
            'UPDATE produtos SET Titulo=?, Preco=?, Descricao=?, Categoria=?, img=? WHERE Cod_produto=?',
            [Titulo || rows[0].Titulo, Preco || rows[0].Preco, Descricao ?? rows[0].Descricao,
             Categoria ?? rows[0].Categoria, newImg, id]
        )
        if (req.file && oldImg) fs.unlink(oldImg, () => {})

        const [updated] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        res.json(updated[0])
    } catch {
        res.status(500).json({ error: 'Erro ao atualizar produto' })
    }
}

// Deletar produto
export async function deleteProduto(req, res) {
    const { id } = req.params
    try {
        const [rows] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        if (!rows.length)
            return res.status(404).json({ error: 'Produto não encontrado' })

        if (req.fornecedor && rows[0].id_fornecedor !== req.fornecedor.idf)
            return res.status(403).json({ error: 'Sem permissão para deletar este produto' })

        const imgPath = rows[0].img
        await pool.query('DELETE FROM produtos WHERE Cod_produto = ?', [id])
        if (imgPath) fs.unlink(imgPath, () => {})
        res.json({ message: 'Produto excluído com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao excluir produto' })
    }
}

import { pool } from '../db.js'
import fs from 'fs'
import path from 'path'

// ══════════════════════════════════════════════════════════════════
// ── CLIENTES - CRUD Completo (Admin)
// ══════════════════════════════════════════════════════════════════

export async function getAllClientes(req, res) {
    try {
        const [clientes] = await pool.query(
            'SELECT idc, name, email, img, telefone, created_at FROM cliente ORDER BY created_at DESC'
        )
        res.json(clientes)
    } catch (err) {
        console.error('Erro ao listar clientes:', err)
        res.status(500).json({ error: 'Erro ao listar clientes' })
    }
}

export async function getClienteById(req, res) {
    const { idc } = req.params
    try {
        const [cliente] = await pool.query(
            'SELECT idc, name, email, img, telefone, created_at FROM cliente WHERE idc = ?',
            [idc]
        )
        if (!cliente.length)
            return res.status(404).json({ error: 'Cliente não encontrado' })
        res.json(cliente[0])
    } catch (err) {
        console.error('Erro ao buscar cliente:', err)
        res.status(500).json({ error: 'Erro ao buscar cliente' })
    }
}

export async function updateCliente(req, res) {
    const { idc } = req.params
    const { name, email, telefone } = req.body

    if (!name || !email || !telefone)
        return res.status(400).json({ error: 'Nome, email e telefone são obrigatórios' })

    try {
        const [cliente] = await pool.query('SELECT * FROM cliente WHERE idc = ?', [idc])
        if (!cliente.length)
            return res.status(404).json({ error: 'Cliente não encontrado' })

        const [updated] = await pool.query(
            'UPDATE cliente SET name = ?, email = ?, telefone = ? WHERE idc = ?',
            [name, email, telefone, idc]
        )

        if (updated.affectedRows === 0)
            return res.status(404).json({ error: 'Cliente não encontrado' })

        const [result] = await pool.query(
            'SELECT idc, name, email, img, telefone, created_at FROM cliente WHERE idc = ?',
            [idc]
        )
        res.json(result[0])
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Email já cadastrado' })
        console.error('Erro ao atualizar cliente:', err)
        res.status(500).json({ error: 'Erro ao atualizar cliente' })
    }
}

export async function deleteCliente(req, res) {
    const { idc } = req.params

    try {
        const [cliente] = await pool.query('SELECT * FROM cliente WHERE idc = ?', [idc])
        if (!cliente.length)
            return res.status(404).json({ error: 'Cliente não encontrado' })

        const imgPath = cliente[0].img
        await pool.query('DELETE FROM cliente WHERE idc = ?', [idc])

        if (imgPath && fs.existsSync(imgPath))
            fs.unlink(imgPath, err => { if (err) console.warn('Erro ao remover imagem:', err) })

        res.json({ message: 'Cliente deletado com sucesso' })
    } catch (err) {
        console.error('Erro ao deletar cliente:', err)
        res.status(500).json({ error: 'Erro ao deletar cliente' })
    }
}

// ══════════════════════════════════════════════════════════════════
// ── FORNECEDORES - CRUD Completo (Admin)
// ══════════════════════════════════════════════════════════════════

export async function getAllFornecedores(req, res) {
    try {
        const [fornecedores] = await pool.query(
            'SELECT id_fornecedor, name, cnpj, email, img, created_at FROM fornecedor ORDER BY created_at DESC'
        )
        res.json(fornecedores)
    } catch (err) {
        console.error('Erro ao listar fornecedores:', err)
        res.status(500).json({ error: 'Erro ao listar fornecedores' })
    }
}

export async function getFornecedorById(req, res) {
    const { idf } = req.params
    try {
        const [fornecedor] = await pool.query(
            'SELECT id_fornecedor, name, cnpj, email, img, created_at FROM fornecedor WHERE id_fornecedor = ?',
            [idf]
        )
        if (!fornecedor.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        res.json(fornecedor[0])
    } catch (err) {
        console.error('Erro ao buscar fornecedor:', err)
        res.status(500).json({ error: 'Erro ao buscar fornecedor' })
    }
}

export async function updateFornecedor(req, res) {
    const { idf } = req.params
    const { name, cnpj, email } = req.body

    if (!name || !cnpj || !email)
        return res.status(400).json({ error: 'Nome, CNPJ e email são obrigatórios' })

    try {
        const [fornecedor] = await pool.query('SELECT * FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (!fornecedor.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })

        const [updated] = await pool.query(
            'UPDATE fornecedor SET name = ?, cnpj = ?, email = ? WHERE id_fornecedor = ?',
            [name, cnpj, email, idf]
        )

        if (updated.affectedRows === 0)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })

        const [result] = await pool.query(
            'SELECT id_fornecedor, name, cnpj, email, img, created_at FROM fornecedor WHERE id_fornecedor = ?',
            [idf]
        )
        res.json(result[0])
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'CNPJ ou Email já cadastrado' })
        console.error('Erro ao atualizar fornecedor:', err)
        res.status(500).json({ error: 'Erro ao atualizar fornecedor' })
    }
}

export async function deleteFornecedor(req, res) {
    const { idf } = req.params

    try {
        const [fornecedor] = await pool.query('SELECT * FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (!fornecedor.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })

        const imgPath = fornecedor[0].img

        // Deletar todos os produtos deste fornecedor
        const [produtos] = await pool.query('SELECT * FROM produtos WHERE id_fornecedor = ?', [idf])
        for (const produto of produtos) {
            if (produto.img_capa && fs.existsSync(produto.img_capa))
                fs.unlink(produto.img_capa, err => { if (err) console.warn('Erro ao remover imagem:', err) })
            if (produto.img_galeria) {
                try {
                    const galeria = JSON.parse(produto.img_galeria)
                    if (Array.isArray(galeria)) {
                        galeria.forEach(img => {
                            if (fs.existsSync(img))
                                fs.unlink(img, err => { if (err) console.warn('Erro ao remover imagem:', err) })
                        })
                    }
                } catch (e) { console.warn('Erro ao processar galeria:', e) }
            }
        }

        await pool.query('DELETE FROM produtos WHERE id_fornecedor = ?', [idf])
        await pool.query('DELETE FROM fornecedor WHERE id_fornecedor = ?', [idf])

        if (imgPath && fs.existsSync(imgPath))
            fs.unlink(imgPath, err => { if (err) console.warn('Erro ao remover imagem:', err) })

        res.json({ message: 'Fornecedor e seus produtos deletados com sucesso' })
    } catch (err) {
        console.error('Erro ao deletar fornecedor:', err)
        res.status(500).json({ error: 'Erro ao deletar fornecedor' })
    }
}

// ══════════════════════════════════════════════════════════════════
// ── PRODUTOS - CRUD Completo (Admin)
// ══════════════════════════════════════════════════════════════════

export async function getAllProdutos(req, res) {
    try {
        const [produtos] = await pool.query(
            'SELECT Cod_produto, Titulo, Descricao, Categoria, Preco, img_capa, id_fornecedor, created_at FROM produtos ORDER BY created_at DESC'
        )
        res.json(produtos)
    } catch (err) {
        console.error('Erro ao listar produtos:', err)
        res.status(500).json({ error: 'Erro ao listar produtos' })
    }
}

export async function getProdutoById(req, res) {
    const { id } = req.params
    try {
        const [produto] = await pool.query(
            'SELECT * FROM produtos WHERE Cod_produto = ?',
            [id]
        )
        if (!produto.length)
            return res.status(404).json({ error: 'Produto não encontrado' })
        res.json(produto[0])
    } catch (err) {
        console.error('Erro ao buscar produto:', err)
        res.status(500).json({ error: 'Erro ao buscar produto' })
    }
}

export async function updateProduto(req, res) {
    const { id } = req.params
    const { Titulo, Descricao, Categoria, Preco, id_fornecedor } = req.body

    if (!Titulo || !Categoria)
        return res.status(400).json({ error: 'Título e categoria são obrigatórios' })

    try {
        const [produto] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        if (!produto.length)
            return res.status(404).json({ error: 'Produto não encontrado' })

        const [updated] = await pool.query(
            'UPDATE produtos SET Titulo = ?, Descricao = ?, Categoria = ?, Preco = ?, id_fornecedor = ? WHERE Cod_produto = ?',
            [Titulo, Descricao || null, Categoria, Preco || null, id_fornecedor || produto[0].id_fornecedor, id]
        )

        if (updated.affectedRows === 0)
            return res.status(404).json({ error: 'Produto não encontrado' })

        const [result] = await pool.query(
            'SELECT * FROM produtos WHERE Cod_produto = ?',
            [id]
        )
        res.json(result[0])
    } catch (err) {
        console.error('Erro ao atualizar produto:', err)
        res.status(500).json({ error: 'Erro ao atualizar produto' })
    }
}

export async function deleteProduto(req, res) {
    const { id } = req.params

    try {
        const [produto] = await pool.query('SELECT * FROM produtos WHERE Cod_produto = ?', [id])
        if (!produto.length)
            return res.status(404).json({ error: 'Produto não encontrado' })

        const { img_capa, img_galeria } = produto[0]

        if (img_capa && fs.existsSync(img_capa))
            fs.unlink(img_capa, err => { if (err) console.warn('Erro ao remover imagem:', err) })

        if (img_galeria) {
            try {
                const galeria = JSON.parse(img_galeria)
                if (Array.isArray(galeria)) {
                    galeria.forEach(img => {
                        if (fs.existsSync(img))
                            fs.unlink(img, err => { if (err) console.warn('Erro ao remover imagem:', err) })
                    })
                }
            } catch (e) { console.warn('Erro ao processar galeria:', e) }
        }

        await pool.query('DELETE FROM produtos WHERE Cod_produto = ?', [id])
        res.json({ message: 'Produto deletado com sucesso' })
    } catch (err) {
        console.error('Erro ao deletar produto:', err)
        res.status(500).json({ error: 'Erro ao deletar produto' })
    }
}

import { Router } from 'express'
import upload from './uploadConfig.js'
import { verifyTokenMiddleware } from './middlewares/authMiddleware.js'
import { registerADM, loginADM, logoutADM, forgotPasswordADM, solicitarCodigoADM, verificarCodigoADM } from './controllers/authADMController.js'
import { getUsersADM, getADMByRA, createUserADM, updateUserADM, deleteUserADM, profileADM, updateMeADM } from './controllers/ADMController.js'
import { registerClient, loginClient, logoutClient, forgotPasswordClient, solicitarCodigoCliente, verificarCodigoCliente } from './controllers/authClienteController.js'
import { getUsersClient, getClientByID, createUserClient, updateUserClient, deleteUserClient, profileClient, updateMeClient } from './controllers/ClienteController.js'
import { registerFornecedor, loginFornecedor, logoutFornecedor, forgotPasswordFornecedor, solicitarCodigoFornecedor, verificarCodigoFornecedor } from './controllers/authFornecedorController.js'
import { getUsersFornecedor, getFornecedorByID, createUserFornecedor, updateUserFornecedor, deleteUserFornecedor, profileFornecedor, updateMeFornecedor } from './controllers/FornecedorController.js'
import { getProdutos, getProdutoById, createProduto, updateProduto as updateProdutoFornecedor, deleteProduto as deleteProdutoFornecedor } from './controllers/ProdutoController.js'
import { listarAvaliacoes, criarAvaliacao, excluirAvaliacao } from './controllers/AvaliacaoController.js'
import { verificarPerfilExistente, trocarPerfil, criarPerfilClienteVinculado, criarPerfilFornecedorVinculado } from './controllers/TrocaPerfilController.js'
import { seguirFornecedor, deixarDeSeguirFornecedor, listarSeguindoCliente, buscarSeguidoresFornecedor, buscarAnalyticsSeguidores } from './controllers/SeguidorController.js'
import { adicionarFavorito, removerFavorito, listarFavoritos, verificarFavorito } from './controllers/FavoritoController.js'
import { iniciarConversa, aceitarConversa, recusarConversa, listarConversas, listarMensagens, enviarMensagem, buscarStatusFornecedor, heartbeatFornecedor } from './controllers/ChatController.js'
import { criarNotificacao, listarNotificacoes, marcarComoLida, marcarTodasComoLidas, excluirNotificacao } from './controllers/NotificacaoController.js'
import {
  getAllClientes, createCliente, getClienteById, updateCliente, deleteCliente,
  getAllFornecedores, createFornecedor, getFornecedorById, updateFornecedor, deleteFornecedor,
  getAllProdutos, createProduto as createProdutoAdmin, getProdutoById as getProdutoByIdAdmin, updateProduto as updateProdutoAdmin, deleteProduto as deleteProdutoAdmin,
  getAllAvaliacoes, updateAvaliacao, deleteAvaliacaoAdmin
} from './controllers/AdminDashboardController.js'

// Middleware para verificar se é ADM
const verifyADM = (req, res, next) => {
  if (!req.adm)
    return res.status(403).json({ error: 'Acesso restrito a Administradores' })
  next()
}

// Middleware opcional: popula req.cliente se token válido, mas não bloqueia se ausente
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization']
    const token = authHeader?.split(' ')[1]
    if (token) {
      const { verifyToken } = await import('./services/tokenService.js')
      const decoded = await verifyToken(token)
      req.cliente = decoded.idc ? { idc: decoded.idc } : undefined
      req.fornecedor = decoded.idf ? { idf: decoded.idf } : undefined
    }
  } catch { /* token inválido — continua sem autenticação */ }
  next()
}

const r = Router()

// ── Middleware de logging global para debug ───────────────
r.use((req, res, next) => {
  if (req.path.includes('forgot-password') || req.path.includes('auth')) {
    console.log(`\n📍 [ROUTE] ${req.method} ${req.path}`)
    console.log('Headers:', req.headers)
    console.log('Body:', req.body)
  }
  next()
})

// ── Auth sem token ────────────────────────────────────────
r.post('/auth/register/adm', registerADM)
r.post('/auth/login/adm', loginADM)
r.post('/auth/register/cliente', registerClient)
r.post('/auth/login/cliente', loginClient)
r.post('/auth/register/fornecedor', registerFornecedor)
r.post('/auth/login/fornecedor', loginFornecedor)

// ── Redefinição de senha — 3 etapas por tipo ──────────────
// Etapa 1: solicitar código (envia e-mail)
r.post('/auth/forgot-password/cliente/solicitar',    solicitarCodigoCliente)
r.post('/auth/forgot-password/fornecedor/solicitar', solicitarCodigoFornecedor)
r.post('/auth/forgot-password/adm/solicitar',        solicitarCodigoADM)

// Etapa 2: verificar código
r.post('/auth/forgot-password/cliente/verificar',    verificarCodigoCliente)
r.post('/auth/forgot-password/fornecedor/verificar', verificarCodigoFornecedor)
r.post('/auth/forgot-password/adm/verificar',        verificarCodigoADM)

// Etapa 3: redefinir senha (confirma código + salva nova senha)
r.post('/auth/forgot-password/cliente',    forgotPasswordClient)
r.post('/auth/forgot-password/fornecedor', forgotPasswordFornecedor)
r.post('/auth/forgot-password/adm',        forgotPasswordADM)

// ── Logout (com token) ────────────────────────────────────
r.post('/auth/logout/adm', verifyTokenMiddleware, logoutADM)
r.post('/auth/logout/cliente', verifyTokenMiddleware, logoutClient)
r.post('/auth/logout/fornecedor', verifyTokenMiddleware, logoutFornecedor)

// ── Perfil do usuário logado ──────────────────────────────
r.get('/adm/profile', verifyTokenMiddleware, profileADM)
r.put('/adm/me', verifyTokenMiddleware, updateMeADM)
r.get('/cliente/profile', verifyTokenMiddleware, profileClient)
r.put('/cliente/me', verifyTokenMiddleware, upload.single('image'), updateMeClient)
r.get('/fornecedor/profile', verifyTokenMiddleware, profileFornecedor)
r.put('/fornecedor/me', verifyTokenMiddleware, upload.single('image'), updateMeFornecedor)

// ── CRUD ADM ──────────────────────────────────────────────
r.get('/adm', getUsersADM)
r.get('/adm/:ra', verifyTokenMiddleware, getADMByRA)
r.post('/adm', verifyTokenMiddleware, upload.single('image'), createUserADM)
r.put('/adm/:ra', verifyTokenMiddleware, upload.single('image'), updateUserADM)
r.delete('/adm/:ra', verifyTokenMiddleware, deleteUserADM)

// ── CRUD Cliente ──────────────────────────────────────────
r.get('/cliente', getUsersClient)
r.get('/cliente/seguindo', verifyTokenMiddleware, listarSeguindoCliente)
r.get('/cliente/:idc', verifyTokenMiddleware, getClientByID)
r.post('/cliente', verifyTokenMiddleware, upload.single('image'), createUserClient)
r.put('/cliente/:idc', verifyTokenMiddleware, upload.single('image'), updateUserClient)
r.delete('/cliente/:idc', verifyTokenMiddleware, deleteUserClient)

// ── CRUD Fornecedor ───────────────────────────────────────
r.get('/fornecedor', getUsersFornecedor)
r.get('/fornecedor/:idf', verifyTokenMiddleware, getFornecedorByID)
r.post('/fornecedor', verifyTokenMiddleware, upload.single('image'), createUserFornecedor)
r.put('/fornecedor/:idf', verifyTokenMiddleware, upload.single('image'), updateUserFornecedor)
r.delete('/fornecedor/:idf', verifyTokenMiddleware, deleteUserFornecedor)

// ── Produtos ──────────────────────────────────────────────
r.get('/produto', getProdutos)
r.get('/produto/:id', getProdutoById)
r.post('/produto', verifyTokenMiddleware, upload.array('images', 5), createProduto)
r.put('/produto/:id', verifyTokenMiddleware, upload.array('images', 5), updateProdutoFornecedor)
r.delete('/produto/:id', verifyTokenMiddleware, deleteProdutoFornecedor)

// ── Avaliações ────────────────────────────────────────────
r.get('/produto/:id/avaliacoes', listarAvaliacoes)
r.post('/avaliacoes', verifyTokenMiddleware, criarAvaliacao)
r.delete('/avaliacoes/:id', verifyTokenMiddleware, excluirAvaliacao)

// ── Troca de Perfil ──────────────────────────────────────
r.post('/perfil/verificar', verifyTokenMiddleware, verificarPerfilExistente)
r.post('/perfil/trocar', verifyTokenMiddleware, trocarPerfil)
r.post('/perfil/criar-cliente', verifyTokenMiddleware, criarPerfilClienteVinculado)
r.post('/perfil/criar-fornecedor', verifyTokenMiddleware, criarPerfilFornecedorVinculado)

// ── Seguidores ───────────────────────────────────────────
r.post('/fornecedor/:id/seguir', verifyTokenMiddleware, seguirFornecedor)
r.delete('/fornecedor/:id/seguir', verifyTokenMiddleware, deixarDeSeguirFornecedor)
r.get('/fornecedor/:id/seguidores', optionalAuth, buscarSeguidoresFornecedor)
r.get('/fornecedor/:id/analytics-seguidores', verifyTokenMiddleware, buscarAnalyticsSeguidores)

// ── Favoritos ─────────────────────────────────────────────
r.post('/favoritos', verifyTokenMiddleware, adicionarFavorito)
r.delete('/favoritos', verifyTokenMiddleware, removerFavorito)
r.get('/favoritos', verifyTokenMiddleware, listarFavoritos)
r.get('/favoritos/:produto_id', verifyTokenMiddleware, verificarFavorito)

// ── ADMIN DASHBOARD - Gerenciamento Total ─────────────────
r.get('/admin/clientes', verifyTokenMiddleware, verifyADM, getAllClientes)
r.post('/admin/clientes', verifyTokenMiddleware, verifyADM, createCliente)
r.get('/admin/clientes/:idc', verifyTokenMiddleware, verifyADM, getClienteById)
r.put('/admin/clientes/:idc', verifyTokenMiddleware, verifyADM, updateCliente)
r.delete('/admin/clientes/:idc', verifyTokenMiddleware, verifyADM, deleteCliente)

r.get('/admin/fornecedores', verifyTokenMiddleware, verifyADM, getAllFornecedores)
r.post('/admin/fornecedores', verifyTokenMiddleware, verifyADM, createFornecedor)
r.get('/admin/fornecedores/:idf', verifyTokenMiddleware, verifyADM, getFornecedorById)
r.put('/admin/fornecedores/:idf', verifyTokenMiddleware, verifyADM, updateFornecedor)
r.delete('/admin/fornecedores/:idf', verifyTokenMiddleware, verifyADM, deleteFornecedor)

r.get('/admin/produtos', verifyTokenMiddleware, verifyADM, getAllProdutos)
r.post('/admin/produtos', verifyTokenMiddleware, verifyADM, createProdutoAdmin)
r.get('/admin/produtos/:id', verifyTokenMiddleware, verifyADM, getProdutoByIdAdmin)
r.put('/admin/produtos/:id', verifyTokenMiddleware, verifyADM, updateProdutoAdmin)
r.delete('/admin/produtos/:id', verifyTokenMiddleware, verifyADM, deleteProdutoAdmin)

r.get('/admin/avaliacoes', verifyTokenMiddleware, verifyADM, getAllAvaliacoes)
r.put('/admin/avaliacoes/:id', verifyTokenMiddleware, verifyADM, updateAvaliacao)
r.delete('/admin/avaliacoes/:id', verifyTokenMiddleware, verifyADM, deleteAvaliacaoAdmin)

// ── Chat ─────────────────────────────────────────────
r.post('/chat/iniciar',            verifyTokenMiddleware, iniciarConversa)
r.post('/chat/:id/aceitar',        verifyTokenMiddleware, aceitarConversa)
r.post('/chat/:id/recusar',        verifyTokenMiddleware, recusarConversa)
r.get('/chat/conversas',           verifyTokenMiddleware, listarConversas)
r.get('/chat/:id/mensagens',       verifyTokenMiddleware, listarMensagens)
r.post('/chat/:id/mensagem',       verifyTokenMiddleware, enviarMensagem)
r.get('/fornecedor/:id/status',    optionalAuth,          buscarStatusFornecedor)
r.post('/chat/heartbeat',          verifyTokenMiddleware, heartbeatFornecedor)

// ── Notificações ──────────────────────────────────────────
r.post('/notificacao/criar',     verifyTokenMiddleware, criarNotificacao)
r.get('/notificacoes',           verifyTokenMiddleware, listarNotificacoes)
r.put('/notificacao/:id/lida',   verifyTokenMiddleware, marcarComoLida)
r.put('/notificacoes/lidas',     verifyTokenMiddleware, marcarTodasComoLidas)
r.delete('/notificacao/:id',     verifyTokenMiddleware, excluirNotificacao)

export default r

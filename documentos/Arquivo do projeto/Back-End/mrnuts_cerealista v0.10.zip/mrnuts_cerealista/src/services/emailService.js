// ═══════════════════════════════════════════════════════════════════════════
// EMAIL SERVICE - Nodemailer + Gmail (Mr Nuts Cerealista)
// Localização: src/services/emailService.js
// ═══════════════════════════════════════════════════════════════════════════

import nodemailer from 'nodemailer'

// Modo teste: true = não envia email, apenas exibe no console
const TEST_MODE = process.env.EMAIL_TEST_MODE === 'true' || !process.env.MAIL_USER

let transporter = null

// Inicializar transporter apenas se não estiver em modo teste
if (!TEST_MODE) {
    transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        auth: {
            user: process.env.MAIL_USER,
            pass: process.env.MAIL_PASS
        }
    })
    
    // Verificar conexão
    transporter.verify((err, success) => {
        if (err) {
            console.error('❌ ERRO ao conectar ao Gmail:', err.message)
            console.log('⚠️  Ativando modo TESTE (códigos serão exibidos no console)')
        } else {
            console.log('✅ Nodemailer conectado ao Gmail com sucesso')
        }
    })
}

/**
 * Envia o e-mail de redefinição de senha com o código de verificação.
 * @param {string} destinatario  - E-mail do destinatário
 * @param {string} nomeUsuario   - Nome do destinatário (para personalização)
 * @param {string} codigo        - Código de 6 dígitos gerado
 * @param {string} tipoUsuario   - 'cliente' | 'fornecedor' | 'adm'
 */
export async function enviarEmailRedefinicao(destinatario, nomeUsuario, codigo, tipoUsuario = 'cliente') {
    const tipoLabel = tipoUsuario === 'fornecedor' ? 'Fornecedor'
                    : tipoUsuario === 'adm'        ? 'Administrador'
                    : 'Cliente'

    // Link de cancelamento — apenas informativo na versão atual
    const cancelLink = `${process.env.APP_URL || 'http://localhost:3000'}/api/auth/cancelar-redefinicao?email=${encodeURIComponent(destinatario)}&codigo=${codigo}`

    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; background-color: #f5f5f5; }
            .container { max-width: 600px; margin: 20px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; border-bottom: 3px solid #8b6f47; padding-bottom: 20px; }
            .header h1 { color: #8b6f47; margin: 0; }
            .content { padding: 20px 0; line-height: 1.6; color: #333; }
            .code-box { background-color: #f9f9f9; border-left: 4px solid #8b6f47; padding: 15px; margin: 20px 0; }
            .code { font-size: 32px; font-weight: bold; color: #8b6f47; letter-spacing: 2px; }
            .warning { background-color: #fff3cd; border: 1px solid #ffc107; padding: 10px; border-radius: 4px; color: #333; margin: 15px 0; }
            .footer { text-align: center; border-top: 1px solid #ddd; padding-top: 20px; font-size: 12px; color: #999; }
            a { color: #8b6f47; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🥜 Mr. Nuts Cerealista</h1>
                <p>Redefinição de Senha</p>
            </div>
            
            <div class="content">
                <p>Olá <strong>${nomeUsuario}</strong>,</p>
                
                <p>Você solicitou a redefinição de senha para sua conta de ${tipoLabel}.</p>
                
                <p>Use o código abaixo para confirmar sua identidade e redefinir sua senha:</p>
                
                <div class="code-box">
                    <p style="margin: 0; text-align: center; font-size: 14px; color: #999;">Código de Verificação</p>
                    <p style="margin: 10px 0 0 0; text-align: center;"><span class="code">${codigo}</span></p>
                    <p style="margin: 10px 0 0 0; text-align: center; color: #999; font-size: 12px;">Válido por 15 minutos</p>
                </div>
                
                <p><strong>Este código é exclusivo para você.</strong> Nunca compartilhe com terceiros.</p>
                
                <div class="warning">
                    ⚠️ <strong>Se você não solicitou esta redefinição,</strong> ignore este e-mail ou <a href="${cancelLink}">clique aqui para cancelar</a>.
                </div>
                
                <p>Caso não consiga usar o código, tente novamente solicitando uma nova redefinição.</p>
            </div>
            
            <div class="footer">
                <p>© 2025 Mr. Nuts Cerealista. Todos os direitos reservados.</p>
                <p>Esta é uma mensagem automática. Não responda este e-mail.</p>
            </div>
        </div>
    </body>
    </html>
    `

    // MODO TESTE: Apenas exibir código no console
    if (TEST_MODE) {
        console.log('\n' + '═'.repeat(70))
        console.log('📧 MODO TESTE - Email de Redefinição de Senha')
        console.log('═'.repeat(70))
        console.log(`Para: ${destinatario}`)
        console.log(`Usuario: ${nomeUsuario}`)
        console.log(`Tipo: ${tipoLabel}`)
        console.log('-'.repeat(70))
        console.log(`🔐 CÓDIGO DE VERIFICAÇÃO: ${codigo}`)
        console.log('-'.repeat(70))
        console.log('Válido por 15 minutos\n')
        return { sucesso: true, teste: true, codigo: codigo }
    }

    // MODO PRODUÇÃO: Enviar email real
    try {
        const info = await transporter.sendMail({
            from: process.env.MAIL_USER,
            to: destinatario,
            subject: `[Mr. Nuts] Código de Redefinição de Senha - ${codigo}`,
            html: htmlContent
        })
        console.log('✅ Email enviado:', info.messageId)
        return { sucesso: true, messageId: info.messageId }
    } catch (error) {
        console.error('❌ Erro ao enviar email:', error.message)
        throw new Error(`Falha ao enviar e-mail: ${error.message}`)
    }
}

/**
 * Envia boas-vindas após registro bem-sucedido
 */
export async function enviarEmailBoasVindas(email, nome, tipoUsuario = 'cliente') {
    const tipoLabel = tipoUsuario === 'fornecedor' ? 'Fornecedor'
                    : tipoUsuario === 'adm'        ? 'Administrador'
                    : 'Cliente'

    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; background-color: #f5f5f5; }
            .container { max-width: 600px; margin: 20px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; border-bottom: 3px solid #8b6f47; padding-bottom: 20px; }
            .header h1 { color: #8b6f47; margin: 0; }
            .content { padding: 20px 0; line-height: 1.6; color: #333; }
            .button { display: inline-block; background-color: #8b6f47; color: white; padding: 12px 30px; border-radius: 4px; text-decoration: none; margin: 15px 0; }
            .footer { text-align: center; border-top: 1px solid #ddd; padding-top: 20px; font-size: 12px; color: #999; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🥜 Bem-vindo ao Mr. Nuts Cerealista!</h1>
            </div>
            
            <div class="content">
                <p>Olá <strong>${nome}</strong>,</p>
                
                <p>Sua conta de ${tipoLabel} foi criada com sucesso! 🎉</p>
                
                <p>Você agora pode acessar nossa plataforma e desfrutar de todos os benefícios.</p>
                
                <div style="text-align: center;">
                    <a href="${process.env.APP_URL || 'http://localhost:3000'}" class="button">Acessar Plataforma</a>
                </div>
                
                <p>Se você tiver dúvidas, nossa equipe de suporte está sempre pronta para ajudar.</p>
            </div>
            
            <div class="footer">
                <p>© 2025 Mr. Nuts Cerealista. Todos os direitos reservados.</p>
            </div>
        </div>
    </body>
    </html>
    `

    // MODO TESTE: Apenas exibir no console
    if (TEST_MODE) {
        console.log('\n' + '═'.repeat(70))
        console.log('📧 MODO TESTE - Email de Boas-vindas')
        console.log('═'.repeat(70))
        console.log(`Para: ${email}`)
        console.log(`Nome: ${nome}`)
        console.log(`Tipo: ${tipoLabel}`)
        console.log('═'.repeat(70) + '\n')
        return { sucesso: true, teste: true }
    }

    // MODO PRODUÇÃO
    try {
        await transporter.sendMail({
            from: process.env.MAIL_USER,
            to: email,
            subject: `Bem-vindo ao Mr. Nuts Cerealista, ${nome}!`,
            html: htmlContent
        })
        console.log('✅ Email de boas-vindas enviado para:', email)
    } catch (error) {
        console.error('❌ Erro ao enviar email de boas-vindas:', error)
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// RESET CODE SERVICE - Geração e validação de códigos temporários
// Localização: src/services/resetCodeService.js
// ═══════════════════════════════════════════════════════════════════════════

// Mapa: chave = "tipoUsuario:email"  →  valor = { codigo, expiraEm }
const _codigos = new Map()

const EXPIRACAO_MS   = 15 * 60 * 1000   // 15 minutos
const LIMPAR_CADA_MS = 10 * 60 * 1000   // limpeza automática a cada 10 min

/**
 * Gera e armazena um código de 6 dígitos para o e-mail/tipo informados.
 * Se já existir um código vigente, sobrescreve (reenvio).
 * @param {string} email
 * @param {string} tipo - 'cliente' | 'fornecedor' | 'adm'
 * @returns {string} código gerado
 */
export function gerarCodigo(email, tipo) {
    const codigo = String(Math.floor(100000 + Math.random() * 900000))
    const chave  = _chave(email, tipo)
    const expiraEm = Date.now() + EXPIRACAO_MS
    _codigos.set(chave, { codigo, expiraEm })
    console.log(`📝 Código gerado para ${email} (${tipo}): ${codigo}`)
    return codigo
}

/**
 * Valida o código informado.
 * @returns {{ valido: boolean, motivo?: string }}
 */
export function validarCodigo(email, tipo, codigoInformado) {
    const chave = _chave(email, tipo)
    const armazenado = _codigos.get(chave)

    if (!armazenado) {
        return { valido: false, motivo: 'Código não solicitado ou expirado' }
    }

    if (Date.now() > armazenado.expiraEm) {
        _codigos.delete(chave)
        return { valido: false, motivo: 'Código expirado' }
    }

    if (String(armazenado.codigo) !== String(codigoInformado)) {
        return { valido: false, motivo: 'Código incorreto' }
    }

    return { valido: true }
}

/**
 * Remove o código após uso bem-sucedido.
 */
export function consumirCodigo(email, tipo) {
    const chave = _chave(email, tipo)
    _codigos.delete(chave)
}

// ── Utilitários internos ──────────────────────────────
function _chave(email, tipo) {
    return `${tipo}:${email}`
}

// Limpeza periódica de códigos expirados
setInterval(() => {
    let removidos = 0
    for (const [chave, dados] of _codigos.entries()) {
        if (Date.now() > dados.expiraEm) {
            _codigos.delete(chave)
            removidos++
        }
    }
    if (removidos > 0) {
        console.log(`🧹 Limpeza: ${removidos} código(s) expirado(s) removido(s)`)
    }
}, LIMPAR_CADA_MS)

import { pool } from '../db.js'

/* ── helpers ─────────────────────────────────────────────── */
function resolveUsuario(req) {
  if (req.adm)        return { tipo: 'admin',      id: req.adm.ida }
  if (req.fornecedor) return { tipo: 'fornecedor',  id: req.fornecedor.idf }
  if (req.cliente)    return { tipo: 'cliente',     id: req.cliente.idc }
  return null
}

/* ── POST /notificacao/criar ─────────────────────────────── */
export async function criarNotificacao(req, res) {
  const { usuario_tipo, usuario_id, titulo, mensagem, tipo, referencia_id } = req.body
  if (!usuario_tipo || !usuario_id || !titulo || !mensagem)
    return res.status(400).json({ error: 'Campos obrigatórios ausentes' })
  try {
    const [r] = await pool.query(
      'INSERT INTO notificacoes (usuario_tipo, usuario_id, titulo, mensagem, tipo, referencia_id) VALUES (?,?,?,?,?,?)',
      [usuario_tipo, usuario_id, titulo, mensagem, tipo || 'admin', referencia_id || null]
    )
    res.status(201).json({ id: r.insertId })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Erro ao criar notificação' })
  }
}

/* ── GET /notificacoes ───────────────────────────────────── */
export async function listarNotificacoes(req, res) {
  const u = resolveUsuario(req)
  if (!u) return res.status(403).json({ error: 'Não autenticado' })
  try {
    const [rows] = await pool.query(
      'SELECT * FROM notificacoes WHERE usuario_tipo=? AND usuario_id=? ORDER BY created_at DESC LIMIT 50',
      [u.tipo, u.id]
    )
    res.json(rows)
  } catch (e) {
    res.status(500).json({ error: 'Erro ao listar notificações' })
  }
}

/* ── PUT /notificacao/:id/lida ───────────────────────────── */
export async function marcarComoLida(req, res) {
  const u = resolveUsuario(req)
  if (!u) return res.status(403).json({ error: 'Não autenticado' })
  try {
    await pool.query(
      'UPDATE notificacoes SET lida=TRUE WHERE id=? AND usuario_tipo=? AND usuario_id=?',
      [req.params.id, u.tipo, u.id]
    )
    res.json({ ok: true })
  } catch {
    res.status(500).json({ error: 'Erro ao marcar como lida' })
  }
}

/* ── PUT /notificacoes/lidas ─────────────────────────────── */
export async function marcarTodasComoLidas(req, res) {
  const u = resolveUsuario(req)
  if (!u) return res.status(403).json({ error: 'Não autenticado' })
  try {
    await pool.query(
      'UPDATE notificacoes SET lida=TRUE WHERE usuario_tipo=? AND usuario_id=? AND lida=FALSE',
      [u.tipo, u.id]
    )
    res.json({ ok: true })
  } catch {
    res.status(500).json({ error: 'Erro ao marcar todas como lidas' })
  }
}

/* ── DELETE /notificacao/:id ─────────────────────────────── */
export async function excluirNotificacao(req, res) {
  const u = resolveUsuario(req)
  if (!u) return res.status(403).json({ error: 'Não autenticado' })
  try {
    await pool.query(
      'DELETE FROM notificacoes WHERE id=? AND usuario_tipo=? AND usuario_id=?',
      [req.params.id, u.tipo, u.id]
    )
    res.json({ ok: true })
  } catch {
    res.status(500).json({ error: 'Erro ao excluir notificação' })
  }
}

/* ── Helpers internos (chamados por outros controllers) ──── */
export async function _criar(usuario_tipo, usuario_id, titulo, mensagem, tipo, referencia_id = null) {
  try {
    await pool.query(
      'INSERT INTO notificacoes (usuario_tipo, usuario_id, titulo, mensagem, tipo, referencia_id) VALUES (?,?,?,?,?,?)',
      [usuario_tipo, usuario_id, titulo, mensagem, tipo, referencia_id]
    )
  } catch (e) { console.error('[notif]', e.message) }
}

/* ── Notificação: nova mensagem (chat) ───────────────────── */
export async function gerarNotificacaoMensagem(destinatario_tipo, destinatario_id, remetente_nome, conversa_id) {
  await _criar(
    destinatario_tipo, destinatario_id,
    'Nova mensagem recebida',
    `${remetente_nome} enviou uma mensagem`,
    'mensagem', conversa_id
  )
}

/* ── Notificação: meta de fornecedor ─────────────────────── */
export async function gerarNotificacaoMetaFornecedor(fornecedor_id, meta_descricao) {
  await _criar(
    'fornecedor', fornecedor_id,
    'Meta alcançada! 🏆',
    meta_descricao,
    'meta', null
  )
}

/* ── Notificação: recomendação ───────────────────────────── */
export async function gerarNotificacaoRecomendacao(cliente_id, texto, referencia_id = null) {
  await _criar(
    'cliente', cliente_id,
    'Recomendado para você',
    texto,
    'recomendacao', referencia_id
  )
}

/* ── Notificação: novo seguidor ──────────────────────────── */
export async function gerarNotificacaoSeguidor(fornecedor_id, total_seguidores) {
  const metas = [5, 10, 25, 50, 100, 250, 500, 1000]
  if (metas.includes(total_seguidores)) {
    await gerarNotificacaoMetaFornecedor(fornecedor_id, `Você alcançou ${total_seguidores} seguidores!`)
  }
  await _criar(
    'fornecedor', fornecedor_id,
    'Novo seguidor!',
    `Você agora tem ${total_seguidores} ${total_seguidores === 1 ? 'seguidor' : 'seguidores'}`,
    'seguidores', null
  )
}

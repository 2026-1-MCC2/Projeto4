import { pool } from '../db.js'
import bcrypt from 'bcrypt'
import { createToken, denyToken } from '../services/tokenService.js'
import { gerarCodigo, validarCodigo, consumirCodigo } from '../services/resetCodeService.js'
import { enviarEmailRedefinicao, enviarEmailBoasVindas } from '../services/emailService.js'

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const TIPO = 'cliente'

const sanitizeClient = (u) => ({
    idc: u.idc, name: u.name, email: u.email, telefone: u.telefone, img: u.img || null
})

// Criar conta
export async function registerClient(req, res) {
    const { name, email, telefone, password, passwordConfirm } = req.body
    if (!name || !email || !telefone || !password)
        return res.status(400).json({ error: 'Name, email, telefone e Password são Obrigatórios' })
    if (passwordConfirm !== undefined && password !== passwordConfirm)
    return res.status(400).json({ error: 'As senhas não correspondem' })
  
  if (!emailRegex.test(email))
        return res.status(400).json({ error: 'Email Inválido' })
    try {
        const hash = await bcrypt.hash(password, 10)
        const [result] = await pool.query(
            'INSERT INTO cliente (name, email, telefone, password) VALUES(?, ?, ?, ?)',
            [name, email, telefone, hash]
        )
        res.status(201).json({ idc: result.insertId, name, email, telefone })
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Email já Cadastrado' })
        res.status(500).json({ error: 'Erro ao registrar o Cliente' })
    }
}

// Login
export async function loginClient(req, res) {
    const { email, password } = req.body
    if (!email || !password)
        return res.status(400).json({ error: 'Email e Password Obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM cliente WHERE email = ?', [email])
        if (!rows.length)
            return res.status(401).json({ error: 'Credenciais Inválidas' })
        const cliente = rows[0]
        const match = await bcrypt.compare(password, cliente.password)
        if (!match)
            return res.status(401).json({ error: 'Credenciais Inválidas' })
        const { token } = createToken({ idc: cliente.idc })  // payload com 'idc'
        res.json({ token, cliente: sanitizeClient(cliente) })
    } catch {
        res.status(500).json({ error: 'Erro no Login' })
    }
}

// Logout
export async function logoutClient(req, res) {
    try {
        denyToken(req.cliente?.jti || req.user?.jti)
        res.json({ message: 'Logout realizado com sucesso' })
    } catch (err) {
        console.log('Erro', err.message)
        res.status(500).json({ error: 'Erro no Logout' })
    }
}

// ── ETAPA 1: Solicitar código por e-mail ─────────────
export async function solicitarCodigoCliente(req, res) {
    console.log('\n🔍 [solicitarCodigoCliente] Requisição recebida')
    console.log('Body:', req.body)
    
    const { email } = req.body
    if (!email) {
        console.log('❌ Email não fornecido')
        return res.status(400).json({ error: 'Email é obrigatório' })
    }
    if (!emailRegex.test(email)) {
        console.log('❌ Email inválido:', email)
        return res.status(400).json({ error: 'Email inválido' })
    }

    try {
        console.log('🔎 Procurando cliente com email:', email)
        const [rows] = await pool.query('SELECT name FROM cliente WHERE email = ?', [email])
        console.log('📊 Resultado da query:', rows)
        
        if (!rows.length) {
            console.log('❌ Cliente não encontrado')
            return res.status(404).json({ error: 'Email não encontrado' })
        }

        const cliente = rows[0]
        console.log('✅ Cliente encontrado:', cliente.name)
        
        const codigo = gerarCodigo(email, TIPO)
        console.log('🔐 Código gerado:', codigo)
        
        try {
            const resultadoEmail = await enviarEmailRedefinicao(email, cliente.name, codigo, TIPO)
            console.log('✅ Email processado:', resultadoEmail)
            const resposta = { message: 'Código enviado para o e-mail. Válido por 15 minutos.' }
            if (resultadoEmail?.teste) resposta.codigo_teste = resultadoEmail.codigo
            res.json(resposta)
        } catch (emailErr) {
            console.error('❌ Erro ao enviar email:', emailErr)
            res.status(500).json({ error: 'Erro ao enviar e-mail de recuperação' })
        }
    } catch (err) {
        console.error('❌ Erro em solicitarCodigoCliente:', err)
        res.status(500).json({ error: 'Erro ao solicitar código' })
    }
}

// ── ETAPA 2: Verificar código ─────────────────────────
export async function verificarCodigoCliente(req, res) {
    const { email, codigo } = req.body
    if (!email || !codigo)
        return res.status(400).json({ error: 'Email e código são obrigatórios' })

    const validacao = validarCodigo(email, TIPO, codigo)
    if (!validacao.valido)
        return res.status(400).json({ error: validacao.motivo })

    res.json({ message: 'Código válido. Você pode redefinir sua senha agora.' })
}

// ── ETAPA 3: Redefinir senha (com código validado) ────
export async function forgotPasswordClient(req, res) {
    const { email, codigo, newPassword, passwordConfirm } = req.body
    if (!email || !codigo || !newPassword)
        return res.status(400).json({ error: 'Email, código e nova senha são obrigatórios' })
    if (passwordConfirm !== undefined && newPassword !== passwordConfirm)
        return res.status(400).json({ error: 'As senhas não correspondem' })

    const validacao = validarCodigo(email, TIPO, codigo)
    if (!validacao.valido)
        return res.status(400).json({ error: validacao.motivo })

    try {
        const hash = await bcrypt.hash(newPassword, 10)
        const [result] = await pool.query(
            'UPDATE cliente SET password = ? WHERE email = ?',
            [hash, email]
        )
        
        if (result.affectedRows === 0)
            return res.status(404).json({ error: 'Usuário não encontrado' })

        consumirCodigo(email, TIPO)
        res.json({ message: 'Senha redefinida com sucesso' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro ao redefinir senha' })
    }
}

// ── Versão legacy (mantida para compatibilidade) ─────
export async function forgotPasswordClientOld(req, res) {
    const { email, newPassword } = req.body
    if (!email || !newPassword)
        return res.status(400).json({ error: 'email e newPassword são obrigatórios' })
    try {
        const hash = await bcrypt.hash(newPassword, 10)
        await pool.query('UPDATE cliente SET password = ? WHERE email = ?', [hash, email])
        res.json({ message: 'Se o email existir, a senha foi redefinida' })
    } catch {
        res.status(500).json({ error: 'Erro ao redefinir senha' })
    }
}
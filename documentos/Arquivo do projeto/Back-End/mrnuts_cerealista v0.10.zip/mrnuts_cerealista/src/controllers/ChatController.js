import { pool } from '../db.js'

// ── Iniciar conversa (cliente → fornecedor) ───────────
export async function iniciarConversa(req, res) {
    try {
        const cliente_id    = req.cliente?.idc
        const { fornecedor_id } = req.body
        if (!cliente_id)    return res.status(403).json({ error: 'Apenas clientes' })
        if (!fornecedor_id) return res.status(400).json({ error: 'fornecedor_id obrigatório' })

        // Verificar se já existe conversa ativa entre os dois
        const [[existente]] = await pool.query(
            `SELECT id, status FROM conversas
             WHERE cliente_id = ? AND fornecedor_id = ?
             AND status IN ('pendente','aceita')`,
            [cliente_id, fornecedor_id]
        )
        if (existente) return res.json({ id: existente.id, status: existente.status, existente: true })

        const [result] = await pool.query(
            `INSERT INTO conversas (cliente_id, fornecedor_id, status) VALUES (?, ?, 'pendente')`,
            [cliente_id, fornecedor_id]
        )

        // ── Notificar fornecedor sobre nova solicitação ───────
        try {
            const { _criar } = await import('./NotificacaoController.js')
            const [[cli]] = await pool.query('SELECT Nome FROM cliente WHERE id_cliente = ?', [cliente_id])
            const nome = cli?.Nome || 'Um cliente'
            await _criar('fornecedor', fornecedor_id,
                'Nova solicitação de conversa',
                `${nome} quer conversar com você`,
                'chat', result.insertId)
        } catch {}

        res.status(201).json({ id: result.insertId, status: 'pendente', existente: false })
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Aceitar conversa (fornecedor) ────────────────────
export async function aceitarConversa(req, res) {
    try {
        const fornecedor_id = req.fornecedor?.idf
        const { id } = req.params
        if (!fornecedor_id) return res.status(403).json({ error: 'Apenas fornecedores' })

        const [[conv]] = await pool.query('SELECT * FROM conversas WHERE id = ?', [id])
        if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' })
        if (conv.fornecedor_id !== fornecedor_id) return res.status(403).json({ error: 'Sem permissão' })

        await pool.query("UPDATE conversas SET status = 'aceita', updated_at = NOW() WHERE id = ?", [id])
        res.json({ message: 'Conversa aceita' })
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Recusar conversa (fornecedor) ────────────────────
export async function recusarConversa(req, res) {
    try {
        const fornecedor_id = req.fornecedor?.idf
        const { id } = req.params
        if (!fornecedor_id) return res.status(403).json({ error: 'Apenas fornecedores' })

        const [[conv]] = await pool.query('SELECT * FROM conversas WHERE id = ?', [id])
        if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' })
        if (conv.fornecedor_id !== fornecedor_id) return res.status(403).json({ error: 'Sem permissão' })

        await pool.query("UPDATE conversas SET status = 'recusada', updated_at = NOW() WHERE id = ?", [id])
        res.json({ message: 'Conversa recusada' })
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Listar conversas (cliente ou fornecedor) ─────────
export async function listarConversas(req, res) {
    try {
        const cliente_id    = req.cliente?.idc
        const fornecedor_id = req.fornecedor?.idf

        let rows
        if (cliente_id) {
            [rows] = await pool.query(
                `SELECT c.*, f.name AS fornecedor_nome, f.img AS fornecedor_img,
                        f.online_at,
                        (SELECT m.mensagem FROM mensagens m WHERE m.conversa_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS ultima_mensagem,
                        (SELECT m.created_at FROM mensagens m WHERE m.conversa_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS ultima_at
                 FROM conversas c
                 JOIN fornecedor f ON f.id_fornecedor = c.fornecedor_id
                 WHERE c.cliente_id = ?
                 ORDER BY c.updated_at DESC`,
                [cliente_id]
            )
        } else if (fornecedor_id) {
            [rows] = await pool.query(
                `SELECT c.*, cl.name AS cliente_nome, cl.img AS cliente_img,
                        (SELECT m.mensagem FROM mensagens m WHERE m.conversa_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS ultima_mensagem,
                        (SELECT m.created_at FROM mensagens m WHERE m.conversa_id = c.id ORDER BY m.created_at DESC LIMIT 1) AS ultima_at
                 FROM conversas c
                 JOIN cliente cl ON cl.idc = c.cliente_id
                 WHERE c.fornecedor_id = ?
                 ORDER BY c.updated_at DESC`,
                [fornecedor_id]
            )
        } else {
            return res.status(403).json({ error: 'Sem permissão' })
        }

        res.json(rows)
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Listar mensagens de uma conversa ─────────────────
export async function listarMensagens(req, res) {
    try {
        const { id } = req.params
        const cliente_id    = req.cliente?.idc
        const fornecedor_id = req.fornecedor?.idf

        const [[conv]] = await pool.query('SELECT * FROM conversas WHERE id = ?', [id])
        if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' })

        // Verificar acesso
        if (cliente_id && conv.cliente_id !== cliente_id)       return res.status(403).json({ error: 'Sem permissão' })
        if (fornecedor_id && conv.fornecedor_id !== fornecedor_id) return res.status(403).json({ error: 'Sem permissão' })

        const [msgs] = await pool.query(
            `SELECT * FROM mensagens WHERE conversa_id = ? ORDER BY created_at ASC`, [id]
        )

        // Marcar mensagens como visualizadas
        const tipo = cliente_id ? 'cliente' : 'fornecedor'
        await pool.query(
            `UPDATE mensagens SET visualizada = 1
             WHERE conversa_id = ? AND remetente_tipo != ? AND visualizada = 0`,
            [id, tipo]
        )

        res.json({ conversa: conv, mensagens: msgs })
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Enviar mensagem ───────────────────────────────────
export async function enviarMensagem(req, res) {
    try {
        const { id } = req.params
        const { mensagem } = req.body
        const cliente_id    = req.cliente?.idc
        const fornecedor_id = req.fornecedor?.idf

        if (!mensagem?.trim()) return res.status(400).json({ error: 'Mensagem não pode ser vazia' })

        const [[conv]] = await pool.query('SELECT * FROM conversas WHERE id = ?', [id])
        if (!conv) return res.status(404).json({ error: 'Conversa não encontrada' })
        if (conv.status !== 'aceita') return res.status(403).json({ error: 'Conversa não aceita ainda' })

        const remetente_tipo = cliente_id ? 'cliente' : 'fornecedor'
        const remetente_id   = cliente_id || fornecedor_id

        if (cliente_id && conv.cliente_id !== cliente_id)          return res.status(403).json({ error: 'Sem permissão' })
        if (fornecedor_id && conv.fornecedor_id !== fornecedor_id) return res.status(403).json({ error: 'Sem permissão' })

        const [result] = await pool.query(
            `INSERT INTO mensagens (conversa_id, remetente_tipo, remetente_id, mensagem)
             VALUES (?, ?, ?, ?)`,
            [id, remetente_tipo, remetente_id, mensagem.trim()]
        )
        await pool.query("UPDATE conversas SET updated_at = NOW() WHERE id = ?", [id])

        // ── Notificar destinatário ────────────────────────────
        try {
            const { gerarNotificacaoMensagem } = await import('./NotificacaoController.js')
            const dest_tipo = remetente_tipo === 'cliente' ? 'fornecedor' : 'cliente'
            const dest_id   = remetente_tipo === 'cliente' ? conv.fornecedor_id : conv.cliente_id
            const [[rem_cliente]] = remetente_tipo === 'cliente'
                ? await pool.query('SELECT Nome FROM cliente WHERE id_cliente = ?', [remetente_id])
                : [[{ Nome: 'Fornecedor' }]]
            const [[rem_forn]] = remetente_tipo === 'fornecedor'
                ? await pool.query('SELECT nome_loja FROM fornecedor WHERE id_fornecedor = ?', [remetente_id])
                : [[{ nome_loja: null }]]
            const nome_rem = rem_forn?.nome_loja || rem_cliente?.Nome || 'Usuário'
            await gerarNotificacaoMensagem(dest_tipo, dest_id, nome_rem, id)
        } catch {}

        const [[nova]] = await pool.query('SELECT * FROM mensagens WHERE id = ?', [result.insertId])
        res.status(201).json(nova)
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Status online do fornecedor ───────────────────────
export async function buscarStatusFornecedor(req, res) {
    try {
        const { id } = req.params
        const [[f]] = await pool.query(
            'SELECT id_fornecedor, online_at FROM fornecedor WHERE id_fornecedor = ?', [id]
        )
        if (!f) return res.status(404).json({ error: 'Fornecedor não encontrado' })

        const agora    = new Date()
        const onlineAt = f.online_at ? new Date(f.online_at) : null
        const diffMin  = onlineAt ? (agora - onlineAt) / 60000 : Infinity
        const online   = diffMin < 5  // online se ativo nos últimos 5 min

        res.json({ online, online_at: f.online_at })
    } catch (err) { res.status(500).json({ error: err.message }) }
}

// ── Atualizar online_at do fornecedor (heartbeat) ────
export async function heartbeatFornecedor(req, res) {
    try {
        const fornecedor_id = req.fornecedor?.idf
        if (!fornecedor_id) return res.status(403).json({ error: 'Apenas fornecedores' })
        await pool.query('UPDATE fornecedor SET online_at = NOW() WHERE id_fornecedor = ?', [fornecedor_id])
        res.json({ ok: true })
    } catch (err) { res.status(500).json({ error: err.message }) }
}

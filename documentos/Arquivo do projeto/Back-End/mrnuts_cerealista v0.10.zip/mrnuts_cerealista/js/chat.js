// ═══════════════════════════════════════════════════════
// CHAT DE NEGÓCIOS - Cliente ↔ Fornecedor
// ═══════════════════════════════════════════════════════

const CHAT = {
    base:          config.API_BASE_URL,
    conversaAtiva: null,
    pollingMsgs:   null,
    pollingConvs:  null,
    heartbeat:     null,
    userType:      null,
    lastMsgCount:  -1      // -1 força render na primeira carga
}

// ══════════════════════════════════════════════
// ABRIR / FECHAR MODAL
// ══════════════════════════════════════════════

async function abrirChat(fornecedorId, fornecedorNome) {
    if (!UserManager.isLoggedIn()) return notify.warning('Faça login para usar o chat')
    CHAT.userType = UserManager.getUserType()
    if (CHAT.userType === config.USER_TYPES.ADMIN) return notify.warning('ADM não participa do chat')

    const modal = document.getElementById('chat-modal')
    if (!modal) { console.error('chat-modal não encontrado no DOM'); return }
    modal.classList.remove('hidden')
    document.body.style.overflow = 'hidden'

    ;(async () => {
        try {
            if (CHAT.userType === config.USER_TYPES.CLIENT && fornecedorId) {
                await _chatIniciarOuAbrirConversa(fornecedorId, fornecedorNome)
            }
            await _chatCarregarConversas()
            _chatIniciarPolling()
            if (CHAT.userType === config.USER_TYPES.SUPPLIER) {
                _chatHeartbeat()
                CHAT.heartbeat = setInterval(_chatHeartbeat, 60000)
            }
        } catch (err) {
            console.error('Erro ao carregar chat:', err)
        }
    })()
}

function fecharChat() {
    document.getElementById('chat-modal').classList.add('hidden')
    document.body.style.overflow = ''
    clearInterval(CHAT.pollingMsgs)
    clearInterval(CHAT.pollingConvs)
    clearInterval(CHAT.heartbeat)
    CHAT.pollingMsgs = CHAT.pollingConvs = CHAT.heartbeat = null
    CHAT.conversaAtiva = null
    CHAT.lastMsgCount  = -1
}

// ══════════════════════════════════════════════
// INICIAR OU RECUPERAR CONVERSA
// ══════════════════════════════════════════════

async function _chatIniciarOuAbrirConversa(fornecedorId, fornecedorNome) {
    try {
        const res  = await fetch(`${CHAT.base}/chat/iniciar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${api.getToken()}` },
            body: JSON.stringify({ fornecedor_id: fornecedorId })
        })
        const data = await res.json()
        if (!res.ok) { notify.error(data.error); return }

        CHAT.conversaAtiva = { id: data.id, status: data.status, nome: fornecedorNome }
        CHAT.lastMsgCount  = -1
        _chatRenderAreaMensagens()
        if (data.status === 'aceita') {
            await _chatCarregarMensagens()
            CHAT.pollingMsgs = setInterval(_chatCarregarMensagens, 3000)
        }
    } catch { notify.error('Erro ao iniciar conversa') }
}

// ══════════════════════════════════════════════
// CARREGAR CONVERSAS (SIDEBAR)
// ══════════════════════════════════════════════

async function _chatCarregarConversas() {
    try {
        const res  = await fetch(`${CHAT.base}/chat/conversas`, {
            headers: { 'Authorization': `Bearer ${api.getToken()}` }
        })
        const data = await res.json()
        _chatRenderConversas(data)
    } catch {}
}

function _chatRenderConversas(lista) {
    const el = document.getElementById('chat-sidebar-lista')
    if (!el) return

    if (!lista.length) {
        el.innerHTML = '<p class="chat-vazio">Nenhuma conversa ainda.</p>'
        return
    }

    el.innerHTML = lista.map(c => {
        const isForn    = CHAT.userType === config.USER_TYPES.SUPPLIER
        const nome      = isForn ? c.cliente_nome    : c.fornecedor_nome
        const img       = isForn ? c.cliente_img     : c.fornecedor_img
        const avatarSrc = img ? `${CHAT.base}/../${img}` : 'https://via.placeholder.com/40?text=U'

        const statusBadge = {
            pendente:  '<span class="chat-badge pendente">Pendente</span>',
            aceita:    '<span class="chat-badge aceita">Ativa</span>',
            recusada:  '<span class="chat-badge recusada">Recusada</span>',
            encerrada: '<span class="chat-badge encerrada">Encerrada</span>'
        }[c.status] || ''

        const ativo = CHAT.conversaAtiva?.id === c.id ? 'ativo' : ''
        return `
            <div class="chat-conv-item ${ativo}" data-conv-id="${c.id}"
                 onclick="chatSelecionarConversa(${c.id}, '${(nome||'').replace(/'/g,"\\'")}', '${c.status}', this)">
                <img src="${avatarSrc}" class="chat-conv-avatar"
                     onerror="this.src='https://via.placeholder.com/40?text=U'">
                <div class="chat-conv-info">
                    <div class="chat-conv-nome">${nome || 'Usuário'} ${statusBadge}</div>
                    <div class="chat-conv-ultima">${c.ultima_mensagem || 'Sem mensagens ainda'}</div>
                </div>
            </div>`
    }).join('')
}

// ══════════════════════════════════════════════
// SELECIONAR CONVERSA
// ══════════════════════════════════════════════

async function chatSelecionarConversa(id, nome, status, elClicado) {
    // FIX: parar polling de mensagens da conversa anterior
    clearInterval(CHAT.pollingMsgs)
    CHAT.pollingMsgs  = null

    // FIX: resetar contador ao trocar de conversa — força re-render
    CHAT.lastMsgCount = -1
    CHAT.conversaAtiva = { id, nome, status }

    // Renderiza área (cria #chat-msgs-body no DOM)
    _chatRenderAreaMensagens()

    // FIX: marcar ativo via referência direta, não via event global
    document.querySelectorAll('.chat-conv-item').forEach(el => el.classList.remove('ativo'))
    if (elClicado) elClicado.classList.add('ativo')

    if (status === 'aceita') {
        // Carregar mensagens logo após o DOM existir
        await _chatCarregarMensagens()
        CHAT.pollingMsgs = setInterval(_chatCarregarMensagens, 3000)
    }
}

// ══════════════════════════════════════════════
// ÁREA DE MENSAGENS
// ══════════════════════════════════════════════

function _chatRenderAreaMensagens() {
    const area = document.getElementById('chat-area-msgs')
    if (!area || !CHAT.conversaAtiva) return

    const { status, nome, id } = CHAT.conversaAtiva
    const isForn = CHAT.userType === config.USER_TYPES.SUPPLIER

    const headerHtml = `
        <div class="chat-area-header">
            <span class="chat-area-nome">${nome}</span>
            ${!isForn ? `<span id="chat-status-online" class="chat-online-badge">Verificando...</span>` : ''}
            ${isForn && status === 'pendente' ? `
            <div class="chat-acoes-forn">
                <button class="chat-btn-aceitar" onclick="chatAceitar(${id})"><i class="fas fa-check"></i> Aceitar</button>
                <button class="chat-btn-recusar" onclick="chatRecusar(${id})"><i class="fas fa-times"></i> Recusar</button>
            </div>` : ''}
        </div>`

    const bodyHtml = `<div class="chat-msgs-body" id="chat-msgs-body"></div>`

    let inputHtml
    if (status === 'aceita') {
        inputHtml = `
            <div class="chat-input-area">
                <textarea id="chat-input-msg" placeholder="Digite sua mensagem..."
                    onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();chatEnviarMensagem()}"
                    rows="1"></textarea>
                <button class="chat-btn-enviar" onclick="chatEnviarMensagem()">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>`
    } else if (status === 'pendente' && !isForn) {
        inputHtml = `
            <div class="chat-input-area chat-input-bloqueado">
                <i class="fas fa-clock"></i> Aguardando aprovação do fornecedor...
            </div>`
    } else if (status === 'recusada') {
        inputHtml = `
            <div class="chat-input-area chat-input-bloqueado" style="color:#e74c3c">
                <i class="fas fa-ban"></i> Conversa recusada pelo fornecedor.
            </div>`
    } else {
        inputHtml = ''
    }

    // FIX: setar innerHTML de uma vez — #chat-msgs-body existe no DOM imediatamente após
    area.innerHTML = headerHtml + bodyHtml + (inputHtml || '')

    if (!isForn && CHAT.conversaAtiva) _chatAtualizarStatusOnline()
}

async function _chatCarregarMensagens() {
    if (!CHAT.conversaAtiva) return
    try {
        const res  = await fetch(`${CHAT.base}/chat/${CHAT.conversaAtiva.id}/mensagens`, {
            headers: { 'Authorization': `Bearer ${api.getToken()}` }
        })
        const data = await res.json()
        if (!res.ok) return

        // Status mudou (ex: fornecedor aceitou)
        if (data.conversa.status !== CHAT.conversaAtiva.status) {
            CHAT.conversaAtiva.status = data.conversa.status
            CHAT.lastMsgCount = -1     // FIX: forçar re-render após mudança de status
            _chatRenderAreaMensagens()
            if (data.conversa.status === 'aceita') {
                clearInterval(CHAT.pollingMsgs)
                await _chatCarregarMensagens()
                CHAT.pollingMsgs = setInterval(_chatCarregarMensagens, 3000)
            }
            return
        }

        // FIX: sempre renderizar se lastMsgCount === -1 (troca de conversa ou primeiro load)
        if (data.mensagens.length !== CHAT.lastMsgCount || CHAT.lastMsgCount === -1) {
            CHAT.lastMsgCount = data.mensagens.length
            _chatRenderMensagens(data.mensagens)
        }
    } catch {}
}

function _chatRenderMensagens(msgs) {
    const body = document.getElementById('chat-msgs-body')
    if (!body) return

    const meuTipo = CHAT.userType === config.USER_TYPES.CLIENT ? 'cliente' : 'fornecedor'

    body.innerHTML = msgs.length
        ? msgs.map(m => {
            const meu  = m.remetente_tipo === meuTipo
            const hora = new Date(m.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
            return `
                <div class="chat-msg ${meu ? 'minha' : 'deles'}">
                    <div class="chat-msg-bubble">${m.mensagem}</div>
                    <div class="chat-msg-hora">${hora} ${meu ? (m.visualizada ? '✓✓' : '✓') : ''}</div>
                </div>`
          }).join('')
        : '<p class="chat-vazio">Nenhuma mensagem ainda. Diga olá!</p>'

    body.scrollTop = body.scrollHeight
}

// ══════════════════════════════════════════════
// ENVIAR MENSAGEM
// ══════════════════════════════════════════════

async function chatEnviarMensagem() {
    const input = document.getElementById('chat-input-msg')
    const texto = input?.value?.trim()
    if (!texto || !CHAT.conversaAtiva) return

    try {
        const res = await fetch(`${CHAT.base}/chat/${CHAT.conversaAtiva.id}/mensagem`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${api.getToken()}` },
            body: JSON.stringify({ mensagem: texto })
        })
        if (!res.ok) { const d = await res.json(); notify.error(d.error); return }
        input.value = ''
        CHAT.lastMsgCount = -1   // FIX: força re-render imediato após envio
        await _chatCarregarMensagens()
    } catch { notify.error('Erro ao enviar mensagem') }
}

// ══════════════════════════════════════════════
// ACEITAR / RECUSAR (FORNECEDOR)
// ══════════════════════════════════════════════

async function chatAceitar(id) {
    try {
        const res = await fetch(`${CHAT.base}/chat/${id}/aceitar`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${api.getToken()}` }
        })
        const d = await res.json()
        if (!res.ok) return notify.error(d.error)
        notify.success('Conversa aceita!')
        CHAT.conversaAtiva.status = 'aceita'
        CHAT.lastMsgCount = -1
        _chatRenderAreaMensagens()
        await _chatCarregarMensagens()
        CHAT.pollingMsgs = setInterval(_chatCarregarMensagens, 3000)
        await _chatCarregarConversas()
    } catch { notify.error('Erro') }
}

async function chatRecusar(id) {
    if (!confirm('Recusar esta conversa?')) return
    try {
        const res = await fetch(`${CHAT.base}/chat/${id}/recusar`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${api.getToken()}` }
        })
        const d = await res.json()
        if (!res.ok) return notify.error(d.error)
        notify.success('Conversa recusada')
        CHAT.conversaAtiva = null
        CHAT.lastMsgCount  = -1
        document.getElementById('chat-area-msgs').innerHTML =
            '<div class="chat-placeholder"><i class="fas fa-comments"></i><p>Selecione uma conversa</p></div>'
        await _chatCarregarConversas()
    } catch { notify.error('Erro') }
}

// ══════════════════════════════════════════════
// STATUS ONLINE
// ══════════════════════════════════════════════

async function _chatAtualizarStatusOnline() {
    if (!CHAT.conversaAtiva) return
    try {
        const convs = await fetch(`${CHAT.base}/chat/conversas`, {
            headers: { 'Authorization': `Bearer ${api.getToken()}` }
        }).then(r => r.json())
        const conv = convs.find(c => c.id === CHAT.conversaAtiva.id)
        if (!conv) return

        const res  = await fetch(`${CHAT.base}/fornecedor/${conv.fornecedor_id}/status`)
        const data = await res.json()
        const el   = document.getElementById('chat-status-online')
        if (el) {
            el.textContent = data.online ? '● Online agora' : '○ Indisponível'
            el.className   = `chat-online-badge ${data.online ? 'online' : 'offline'}`
        }
    } catch {}
}

// ══════════════════════════════════════════════
// HEARTBEAT DO FORNECEDOR
// ══════════════════════════════════════════════

async function _chatHeartbeat() {
    try {
        await fetch(`${CHAT.base}/chat/heartbeat`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${api.getToken()}` }
        })
    } catch {}
}

// ══════════════════════════════════════════════
// POLLING
// ══════════════════════════════════════════════

function _chatIniciarPolling() {
    clearInterval(CHAT.pollingConvs)
    CHAT.pollingConvs = setInterval(async () => {
        await _chatCarregarConversas()
        if (CHAT.conversaAtiva?.status === 'aceita') await _chatCarregarMensagens()
        if (CHAT.conversaAtiva && CHAT.userType === config.USER_TYPES.CLIENT) await _chatAtualizarStatusOnline()
    }, 5000)
}

// ══════════════════════════════════════════════
// EXPOR GLOBALMENTE
// ══════════════════════════════════════════════

window.abrirChat              = abrirChat
window.fecharChat             = fecharChat
window.chatSelecionarConversa = chatSelecionarConversa
window.chatEnviarMensagem     = chatEnviarMensagem
window.chatAceitar            = chatAceitar
window.chatRecusar            = chatRecusar
/**
 * notificacoes.js — Mr.Nuts Cerealista
 * Sistema de notificações com polling — padrão idêntico ao user-menu
 */
;(function () {
  'use strict'

  /* ── Config ──────────────────────────────────────────────── */
  const POLL_INTERVAL = 30000
  const API_BASE  = () => (typeof config !== 'undefined' ? config.API_BASE_URL : 'http://localhost:3000/api')
  const getToken  = () => (typeof api    !== 'undefined' ? api.getToken()      : null)

  const TIPO_ICONE = {
    mensagem:     'fa-comment-dots',
    chat:         'fa-comments',
    meta:         'fa-trophy',
    erro:         'fa-exclamation-triangle',
    produto:      'fa-box',
    seguidores:   'fa-users',
    recomendacao: 'fa-star',
    admin:        'fa-shield-alt',
  }

  let notifs    = []
  let pollTimer = null
  let inited    = false

  /* ── Build DOM ───────────────────────────────────────────── */
  function buildDOM() {
    const btn  = document.getElementById('notifications-btn')
    const wrap = document.getElementById('notif-menu')
    if (!btn || !wrap || document.getElementById('notif-dropdown')) return

    // Badge dentro do botão
    const badge = document.createElement('span')
    badge.id = 'notif-badge'
    badge.style.display = 'none'
    btn.appendChild(badge)

    // Dropdown dentro do wrapper (igual ao user-dropdown dentro de user-menu)
    const drop = document.createElement('div')
    drop.id = 'notif-dropdown'
    drop.innerHTML = `
      <div class="notifications-header">
        <h3>Notificações</h3>
        <button id="notif-mark-all">Marcar todas como lidas</button>
      </div>
      <div id="notifications-list"></div>`
    wrap.appendChild(drop)

    // Toggle ao clicar no sino
    btn.addEventListener('click', e => {
      e.stopPropagation()
      const isOpen = drop.classList.contains('show')
      // Fechar outros dropdowns abertos (user-dropdown)
      document.querySelectorAll('.user-dropdown.show').forEach(d => d.classList.remove('show'))
      drop.classList.toggle('show', !isOpen)
    })

    // Fechar ao clicar fora
    document.addEventListener('click', e => {
      if (!wrap.contains(e.target)) drop.classList.remove('show')
    })

    document.getElementById('notif-mark-all').addEventListener('click', marcarTodas)

    // Render inicial vazio
    renderList()
  }

  /* ── Render ──────────────────────────────────────────────── */
  function renderList() {
    const list = document.getElementById('notifications-list')
    if (!list) return

    if (!notifs.length) {
      list.innerHTML = `<div class="notif-empty"><i class="fas fa-bell-slash"></i>Nenhuma notificação</div>`
      return
    }

    list.innerHTML = notifs.map(n => {
      const icone = TIPO_ICONE[n.tipo] || 'fa-bell'
      const tipo  = n.tipo || 'default'
      return `
        <div class="notif-item ${n.lida ? '' : 'notif-unread'}" data-id="${n.id}" data-lida="${n.lida ? '1' : '0'}">
          <div class="notif-icon tipo-${tipo}"><i class="fas ${icone}"></i></div>
          <div class="notif-body">
            <p class="notif-titulo">${esc(n.titulo)}</p>
            <p class="notif-msg">${esc(n.mensagem)}</p>
            <span class="notif-time">${timeAgo(n.created_at)}</span>
          </div>
          <button class="notif-del" data-del="${n.id}" title="Excluir"><i class="fas fa-times"></i></button>
        </div>`
    }).join('')

    list.querySelectorAll('.notif-item').forEach(el => {
      el.addEventListener('click', e => {
        if (e.target.closest('.notif-del')) return
        if (el.dataset.lida === '0') marcarLida(parseInt(el.dataset.id))
      })
    })
    list.querySelectorAll('[data-del]').forEach(b => {
      b.addEventListener('click', e => { e.stopPropagation(); excluir(parseInt(b.dataset.del)) })
    })
  }

  function updateBadge() {
    const badge = document.getElementById('notif-badge')
    if (!badge) return
    const n = notifs.filter(x => !x.lida).length
    badge.textContent   = n > 99 ? '99+' : n
    badge.style.display = n > 0 ? 'flex' : 'none'
  }

  /* ── API ─────────────────────────────────────────────────── */
  async function fetchNotifs() {
    const token = getToken()
    if (!token) return
    try {
      const res = await fetch(`${API_BASE()}/notificacoes`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (!res.ok) return
      notifs = await res.json()
      renderList()
      updateBadge()
    } catch {}
  }

  async function marcarLida(id) {
    const token = getToken(); if (!token) return
    try {
      await fetch(`${API_BASE()}/notificacao/${id}/lida`, {
        method: 'PUT', headers: { Authorization: `Bearer ${token}` }
      })
      const n = notifs.find(x => x.id === id)
      if (n) { n.lida = true; renderList(); updateBadge() }
    } catch {}
  }

  async function marcarTodas() {
    const token = getToken(); if (!token) return
    try {
      await fetch(`${API_BASE()}/notificacoes/lidas`, {
        method: 'PUT', headers: { Authorization: `Bearer ${token}` }
      })
      notifs.forEach(n => n.lida = true)
      renderList(); updateBadge()
    } catch {}
  }

  async function excluir(id) {
    const token = getToken(); if (!token) return
    try {
      await fetch(`${API_BASE()}/notificacao/${id}`, {
        method: 'DELETE', headers: { Authorization: `Bearer ${token}` }
      })
      notifs = notifs.filter(n => n.id !== id)
      renderList(); updateBadge()
    } catch {}
  }

  /* ── Polling ─────────────────────────────────────────────── */
  function startPolling() {
    fetchNotifs()
    if (pollTimer) clearInterval(pollTimer)
    pollTimer = setInterval(fetchNotifs, POLL_INTERVAL)
  }

  function stopPolling() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null }
    notifs = []; renderList(); updateBadge()
  }

  /* ── Init ────────────────────────────────────────────────── */
  function init() {
    if (inited) return
    inited = true
    buildDOM()
    if (getToken()) startPolling()
  }

  window.notificacoesSystem = { init, startPolling, stopPolling, fetch: fetchNotifs }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init)
  } else {
    init()
  }

  function esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
  }
  function timeAgo(d) {
    const s = (Date.now() - new Date(d).getTime()) / 1000
    if (s < 60)    return 'agora'
    if (s < 3600)  return `${Math.floor(s/60)}min`
    if (s < 86400) return `${Math.floor(s/3600)}h`
    return `${Math.floor(s/86400)}d`
  }
})()

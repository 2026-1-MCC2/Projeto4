/* ════════════════════════════════════════════════════════════════════════════════ */
/* ADMIN DASHBOARD - JAVASCRIPT LOGIC                                               */
/* ════════════════════════════════════════════════════════════════════════════════ */

const API_URL = 'http://localhost:3000/api'; // Alterar conforme necessário
const token = localStorage.getItem('token');
const adminUser = JSON.parse(localStorage.getItem('adminUser'));

// Estado da aplicação
let appState = {
    currentTab: 'clientes',
    currentEditItem: null,
    currentDeleteItem: null,
    clientes: [],
    fornecedores: [],
    produtos: [],
    filteredData: {
        clientes: [],
        fornecedores: [],
        produtos: []
    }
};

// ════════════════════════════════════════════════════════════════════════════════
// ──── INICIALIZAÇÃO
// ════════════════════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', async () => {
    // Verificar se o usuário está logado
    if (!token || !adminUser) {
        window.location.href = 'admin-login.html';
        return;
    }

    // Inicializar interface
    initializeUI();
    
    // Carregar dados iniciais
    await loadClientes();
    await loadFornecedores();
    await loadProdutos();

    // Configurar event listeners
    setupEventListeners();
});

// ════════════════════════════════════════════════════════════════════════════════
// ──── INTERFACE
// ════════════════════════════════════════════════════════════════════════════════

function initializeUI() {
    // Mostrar nome e avatar do admin
    document.getElementById('adminName').textContent = adminUser.name || 'Admin';
    document.getElementById('adminAvatar').textContent = (adminUser.name || 'A').charAt(0).toUpperCase();
}

function setupEventListeners() {
    // Tabs de navegação
    document.querySelectorAll('[data-tab]').forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            switchTab(tab.dataset.tab);
        });
    });

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // Busca
    document.getElementById('searchClientes').addEventListener('input', filterClientes);
    document.getElementById('searchFornecedores').addEventListener('input', filterFornecedores);
    document.getElementById('searchProdutos').addEventListener('input', filterProdutos);

    // Modal de edição
    document.getElementById('closeModalBtn').addEventListener('click', closeEditModal);
    document.getElementById('cancelEditBtn').addEventListener('click', closeEditModal);
    document.getElementById('saveEditBtn').addEventListener('click', saveEdit);

    // Modal de exclusão
    document.getElementById('closeDeleteModalBtn').addEventListener('click', closeDeleteModal);
    document.getElementById('cancelDeleteBtn').addEventListener('click', closeDeleteModal);
    document.getElementById('confirmDeleteBtn').addEventListener('click', confirmDelete);
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── NAVIGATION
// ════════════════════════════════════════════════════════════════════════════════

function switchTab(tab) {
    // Remover classe active de todas as abas
    document.querySelectorAll('.admin-tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.querySelectorAll('.admin-sidebar-link').forEach(link => {
        link.classList.remove('active');
    });

    // Adicionar classe active à aba selecionada
    document.getElementById(tab).classList.add('active');
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

    appState.currentTab = tab;
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── CLIENTES
// ════════════════════════════════════════════════════════════════════════════════

async function loadClientes() {
    try {
        const response = await fetch(`${API_URL}/admin/clientes`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Erro ao carregar clientes');

        appState.clientes = await response.json();
        appState.filteredData.clientes = appState.clientes;
        renderClientesTable();
    } catch (error) {
        console.error('Erro ao carregar clientes:', error);
        showError('Erro ao carregar clientes');
    }
}

function renderClientesTable() {
    const tbody = document.getElementById('clientesTableBody');
    
    if (appState.filteredData.clientes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px;">Nenhum cliente encontrado</td></tr>';
        return;
    }

    tbody.innerHTML = appState.filteredData.clientes.map(cliente => `
        <tr>
            <td>${cliente.idc}</td>
            <td>${cliente.name}</td>
            <td>${cliente.email}</td>
            <td>${cliente.telefone}</td>
            <td>${formatDate(cliente.created_at)}</td>
            <td>
                <div class="admin-action-buttons">
                    <button class="btn-edit" onclick="openEditClienteModal(${cliente.idc})">Editar</button>
                    <button class="btn-delete" onclick="openDeleteModal('cliente', ${cliente.idc})">Deletar</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function filterClientes() {
    const search = document.getElementById('searchClientes').value.toLowerCase();
    appState.filteredData.clientes = appState.clientes.filter(cliente =>
        cliente.name.toLowerCase().includes(search) ||
        cliente.email.toLowerCase().includes(search)
    );
    renderClientesTable();
}

async function openEditClienteModal(idc) {
    const cliente = appState.clientes.find(c => c.idc === idc);
    if (!cliente) return;

    appState.currentEditItem = { type: 'cliente', data: cliente };

    document.getElementById('modalTitle').textContent = 'Editar Cliente';
    document.getElementById('editForm').innerHTML = `
        <div class="form-group">
            <label>Nome</label>
            <input type="text" id="editName" value="${cliente.name}" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" id="editEmail" value="${cliente.email}" required>
        </div>
        <div class="form-group">
            <label>Telefone</label>
            <input type="tel" id="editTelefone" value="${cliente.telefone}" required>
        </div>
    `;

    document.getElementById('editModal').classList.add('active');
}

async function updateCliente(idc) {
    const name = document.getElementById('editName').value;
    const email = document.getElementById('editEmail').value;
    const telefone = document.getElementById('editTelefone').value;

    if (!name || !email || !telefone) {
        alert('Todos os campos são obrigatórios');
        return false;
    }

    try {
        const response = await fetch(`${API_URL}/admin/clientes/${idc}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, email, telefone })
        });

        if (!response.ok) throw new Error('Erro ao atualizar cliente');

        await loadClientes();
        return true;
    } catch (error) {
        console.error('Erro ao atualizar cliente:', error);
        alert('Erro ao atualizar cliente');
        return false;
    }
}

async function deleteCliente(idc) {
    try {
        const response = await fetch(`${API_URL}/admin/clientes/${idc}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Erro ao deletar cliente');

        await loadClientes();
        return true;
    } catch (error) {
        console.error('Erro ao deletar cliente:', error);
        alert('Erro ao deletar cliente');
        return false;
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── FORNECEDORES
// ════════════════════════════════════════════════════════════════════════════════

async function loadFornecedores() {
    try {
        const response = await fetch(`${API_URL}/admin/fornecedores`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Erro ao carregar fornecedores');

        appState.fornecedores = await response.json();
        appState.filteredData.fornecedores = appState.fornecedores;
        renderFornecedoresTable();
    } catch (error) {
        console.error('Erro ao carregar fornecedores:', error);
        showError('Erro ao carregar fornecedores');
    }
}

function renderFornecedoresTable() {
    const tbody = document.getElementById('fornecedoresTableBody');
    
    if (appState.filteredData.fornecedores.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 40px;">Nenhum fornecedor encontrado</td></tr>';
        return;
    }

    tbody.innerHTML = appState.filteredData.fornecedores.map(fornecedor => `
        <tr>
            <td>${fornecedor.id_fornecedor}</td>
            <td>${fornecedor.name}</td>
            <td>${fornecedor.cnpj}</td>
            <td>${fornecedor.email}</td>
            <td>${formatDate(fornecedor.created_at)}</td>
            <td>
                <div class="admin-action-buttons">
                    <button class="btn-edit" onclick="openEditFornecedorModal(${fornecedor.id_fornecedor})">Editar</button>
                    <button class="btn-delete" onclick="openDeleteModal('fornecedor', ${fornecedor.id_fornecedor})">Deletar</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function filterFornecedores() {
    const search = document.getElementById('searchFornecedores').value.toLowerCase();
    appState.filteredData.fornecedores = appState.fornecedores.filter(fornecedor =>
        fornecedor.name.toLowerCase().includes(search) ||
        fornecedor.cnpj.toLowerCase().includes(search) ||
        fornecedor.email.toLowerCase().includes(search)
    );
    renderFornecedoresTable();
}

async function openEditFornecedorModal(idf) {
    const fornecedor = appState.fornecedores.find(f => f.id_fornecedor === idf);
    if (!fornecedor) return;

    appState.currentEditItem = { type: 'fornecedor', data: fornecedor };

    document.getElementById('modalTitle').textContent = 'Editar Fornecedor';
    document.getElementById('editForm').innerHTML = `
        <div class="form-group">
            <label>Nome</label>
            <input type="text" id="editName" value="${fornecedor.name}" required>
        </div>
        <div class="form-group">
            <label>CNPJ</label>
            <input type="text" id="editCnpj" value="${fornecedor.cnpj}" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" id="editEmail" value="${fornecedor.email}" required>
        </div>
    `;

    document.getElementById('editModal').classList.add('active');
}

async function updateFornecedor(idf) {
    const name = document.getElementById('editName').value;
    const cnpj = document.getElementById('editCnpj').value;
    const email = document.getElementById('editEmail').value;

    if (!name || !cnpj || !email) {
        alert('Todos os campos são obrigatórios');
        return false;
    }

    try {
        const response = await fetch(`${API_URL}/admin/fornecedores/${idf}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, cnpj, email })
        });

        if (!response.ok) throw new Error('Erro ao atualizar fornecedor');

        await loadFornecedores();
        return true;
    } catch (error) {
        console.error('Erro ao atualizar fornecedor:', error);
        alert('Erro ao atualizar fornecedor');
        return false;
    }
}

async function deleteFornecedor(idf) {
    try {
        const response = await fetch(`${API_URL}/admin/fornecedores/${idf}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Erro ao deletar fornecedor');

        await loadFornecedores();
        return true;
    } catch (error) {
        console.error('Erro ao deletar fornecedor:', error);
        alert('Erro ao deletar fornecedor');
        return false;
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── PRODUTOS
// ════════════════════════════════════════════════════════════════════════════════

async function loadProdutos() {
    try {
        const response = await fetch(`${API_URL}/admin/produtos`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Erro ao carregar produtos');

        appState.produtos = await response.json();
        appState.filteredData.produtos = appState.produtos;
        renderProdutosTable();
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        showError('Erro ao carregar produtos');
    }
}

function renderProdutosTable() {
    const tbody = document.getElementById('produtosTableBody');
    
    if (appState.filteredData.produtos.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;">Nenhum produto encontrado</td></tr>';
        return;
    }

    tbody.innerHTML = appState.filteredData.produtos.map(produto => `
        <tr>
            <td>${produto.Cod_produto}</td>
            <td>${produto.Titulo}</td>
            <td>${produto.Categoria}</td>
            <td>R$ ${parseFloat(produto.Preco).toFixed(2)}</td>
            <td>${produto.id_fornecedor}</td>
            <td>${formatDate(produto.created_at)}</td>
            <td>
                <div class="admin-action-buttons">
                    <button class="btn-edit" onclick="openEditProdutoModal(${produto.Cod_produto})">Editar</button>
                    <button class="btn-delete" onclick="openDeleteModal('produto', ${produto.Cod_produto})">Deletar</button>
                </div>
            </td>
        </tr>
    `).join('');
}

function filterProdutos() {
    const search = document.getElementById('searchProdutos').value.toLowerCase();
    appState.filteredData.produtos = appState.produtos.filter(produto =>
        produto.Titulo.toLowerCase().includes(search) ||
        produto.Categoria.toLowerCase().includes(search)
    );
    renderProdutosTable();
}

async function openEditProdutoModal(codProduto) {
    const produto = appState.produtos.find(p => p.Cod_produto === codProduto);
    if (!produto) return;

    appState.currentEditItem = { type: 'produto', data: produto };

    document.getElementById('modalTitle').textContent = 'Editar Produto';
    document.getElementById('editForm').innerHTML = `
        <div class="form-group">
            <label>Título</label>
            <input type="text" id="editTitulo" value="${produto.Titulo}" required>
        </div>
        <div class="form-group">
            <label>Descrição</label>
            <textarea id="editDescricao" rows="3">${produto.Descricao || ''}</textarea>
        </div>
        <div class="form-group">
            <label>Categoria</label>
            <select id="editCategoria" required>
                <option value="nozes" ${produto.Categoria === 'nozes' ? 'selected' : ''}>Nozes</option>
                <option value="castanhas" ${produto.Categoria === 'castanhas' ? 'selected' : ''}>Castanhas</option>
                <option value="grãos" ${produto.Categoria === 'grãos' ? 'selected' : ''}>Grãos</option>
                <option value="sementes" ${produto.Categoria === 'sementes' ? 'selected' : ''}>Sementes</option>
                <option value="farináceos" ${produto.Categoria === 'farináceos' ? 'selected' : ''}>Farináceos</option>
                <option value="chips" ${produto.Categoria === 'chips' ? 'selected' : ''}>Chips</option>
                <option value="temperos" ${produto.Categoria === 'temperos' ? 'selected' : ''}>Temperos</option>
            </select>
        </div>
        <div class="form-group">
            <label>Preço</label>
            <input type="number" id="editPreco" value="${produto.Preco || ''}" step="0.01" min="0">
        </div>
    `;

    document.getElementById('editModal').classList.add('active');
}

async function updateProduto(codProduto) {
    const Titulo = document.getElementById('editTitulo').value;
    const Descricao = document.getElementById('editDescricao').value;
    const Categoria = document.getElementById('editCategoria').value;
    const Preco = document.getElementById('editPreco').value;

    if (!Titulo || !Categoria) {
        alert('Título e categoria são obrigatórios');
        return false;
    }

    try {
        const response = await fetch(`${API_URL}/admin/produtos/${codProduto}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                Titulo,
                Descricao: Descricao || null,
                Categoria,
                Preco: Preco ? parseFloat(Preco) : null
            })
        });

        if (!response.ok) throw new Error('Erro ao atualizar produto');

        await loadProdutos();
        return true;
    } catch (error) {
        console.error('Erro ao atualizar produto:', error);
        alert('Erro ao atualizar produto');
        return false;
    }
}

async function deleteProduto(codProduto) {
    try {
        const response = await fetch(`${API_URL}/admin/produtos/${codProduto}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) throw new Error('Erro ao deletar produto');

        await loadProdutos();
        return true;
    } catch (error) {
        console.error('Erro ao deletar produto:', error);
        alert('Erro ao deletar produto');
        return false;
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── MODALS
// ════════════════════════════════════════════════════════════════════════════════

function closeEditModal() {
    document.getElementById('editModal').classList.remove('active');
    appState.currentEditItem = null;
}

async function saveEdit() {
    if (!appState.currentEditItem) return;

    const { type, data } = appState.currentEditItem;
    let success = false;

    if (type === 'cliente') {
        success = await updateCliente(data.idc);
    } else if (type === 'fornecedor') {
        success = await updateFornecedor(data.id_fornecedor);
    } else if (type === 'produto') {
        success = await updateProduto(data.Cod_produto);
    }

    if (success) {
        closeEditModal();
        showSuccess('Alterações salvas com sucesso!');
    }
}

function openDeleteModal(type, id) {
    appState.currentDeleteItem = { type, id };
    
    let message = '';
    if (type === 'cliente') message = 'Tem certeza que deseja deletar este cliente?';
    else if (type === 'fornecedor') message = 'Tem certeza que deseja deletar este fornecedor? Todos os seus produtos também serão deletados.';
    else if (type === 'produto') message = 'Tem certeza que deseja deletar este produto?';
    
    document.getElementById('deleteMessage').textContent = message + ' Esta ação não pode ser desfeita.';
    document.getElementById('deleteModal').classList.add('active');
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active');
    appState.currentDeleteItem = null;
}

async function confirmDelete() {
    if (!appState.currentDeleteItem) return;

    const { type, id } = appState.currentDeleteItem;
    let success = false;

    if (type === 'cliente') {
        success = await deleteCliente(id);
    } else if (type === 'fornecedor') {
        success = await deleteFornecedor(id);
    } else if (type === 'produto') {
        success = await deleteProduto(id);
    }

    if (success) {
        closeDeleteModal();
        showSuccess('Item deletado com sucesso!');
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── UTILITIES
// ════════════════════════════════════════════════════════════════════════════════

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showSuccess(message) {
    // Mostrar notificação de sucesso (pode ser implementado com toast)
    console.log('✓', message);
}

function showError(message) {
    // Mostrar notificação de erro (pode ser implementado com toast)
    console.error('✗', message);
}

async function logout() {
    try {
        await fetch(`${API_URL}/auth/logout/adm`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
    } catch (error) {
        console.error('Erro ao fazer logout:', error);
    }

    // Limpar localStorage e redirecionar
    localStorage.removeItem('token');
    localStorage.removeItem('adminUser');
    window.location.href = 'admin-login.html';
}

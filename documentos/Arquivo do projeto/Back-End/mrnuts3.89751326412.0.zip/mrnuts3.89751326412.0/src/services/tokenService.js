import jwt from 'jsonwebtoken'
import { v4 as uuidv4 } from 'uuid'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DENYLIST_PATH = path.resolve(__dirname, '../../denylist.json')

// ── Carrega denylist do disco ao iniciar ──────────────────────────────────────
function loadDenylist() {
    try {
        if (fs.existsSync(DENYLIST_PATH)) {
            const raw = fs.readFileSync(DENYLIST_PATH, 'utf-8')
            return new Set(JSON.parse(raw))
        }
    } catch { /* arquivo corrompido — começa limpo */ }
    return new Set()
}

function saveDenylist(set) {
    try {
        fs.writeFileSync(DENYLIST_PATH, JSON.stringify([...set]), 'utf-8')
    } catch (err) {
        console.error('[tokenService] Erro ao salvar denylist:', err.message)
    }
}

const denylist = loadDenylist()

export const createToken = (payload) => {
    const jti = uuidv4()
    const token = jwt.sign(
        { ...payload, jti },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES || '1h' }
    )
    return { token, jti }
}

export const isDenied = (jti) => denylist.has(jti)

export const denyToken = (jti) => {
    if (jti) {
        denylist.add(jti)
        saveDenylist(denylist)
    }
}

export const verifyToken = (token) => new Promise((resolve, reject) => {
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return reject(err)
        if (isDenied(decoded.jti))
            return reject(new Error('Token denylisted'))
        resolve(decoded)
    })
})
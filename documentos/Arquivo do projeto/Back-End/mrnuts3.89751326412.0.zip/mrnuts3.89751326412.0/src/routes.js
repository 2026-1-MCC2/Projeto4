import { Router } from 'express'
import upload from './uploadConfig.js'
import { verifyTokenMiddleware } from './middlewares/authMiddleware.js'

import { registerADM, loginADM, logoutADM, forgotPasswordADM, verifyOTPADM, resetPasswordADM } from './controllers/authADMController.js'
import { getUsersADM, getADMByRA, createUserADM, updateUserADM, deleteUserADM, profileADM, updateMeADM } from './controllers/ADMController.js'

import { registerClient, loginClient, logoutClient, forgotPasswordClient, verifyOTPClient, resetPasswordClient } from './controllers/authClienteController.js'
import { getUsersClient, getClientByID, createUserClient, updateUserClient, deleteUserClient, profileClient, updateMeClient } from './controllers/ClienteController.js'

import { registerFornecedor, loginFornecedor, logoutFornecedor, forgotPasswordFornecedor, verifyOTPFornecedor, resetPasswordFornecedor } from './controllers/authFornecedorController.js'
import { getUsersFornecedor, getFornecedorByID, createUserFornecedor, updateUserFornecedor, deleteUserFornecedor, profileFornecedor, updateMeFornecedor } from './controllers/FornecedorController.js'

import { getProdutos, getProdutoById, createProduto, updateProduto as updateProdutoFornecedor, deleteProduto as deleteProdutoFornecedor } from './controllers/ProdutoController.js'

import { listarAvaliacoes, criarAvaliacao, excluirAvaliacao } from './controllers/AvaliacaoController.js'

import {
    getAllClientes, getClienteById, updateCliente, deleteCliente,
    getAllFornecedores, getFornecedorById, updateFornecedor, deleteFornecedor,
    getAllProdutos, getProdutoById as getProdutoByIdAdmin, updateProduto as updateProdutoAdmin, deleteProduto as deleteProdutoAdmin
} from './controllers/AdminDashboardController.js'

// Middleware para verificar se é ADM
const verifyADM = (req, res, next) => {
    if (!req.adm)
        return res.status(403).json({ error: 'Acesso restrito a Administradores' })
    next()
}

const r = Router()

// ── Auth ADM ──────────────────────────────────────────────────────────────────
r.post('/auth/register/adm',         registerADM)
r.post('/auth/login/adm',            loginADM)
r.post('/auth/verify-otp/adm',       verifyOTPADM)
r.post('/auth/forgot-password/adm',  forgotPasswordADM)
r.post('/auth/reset-password/adm',   resetPasswordADM)       // ← NOVO (2ª etapa)
r.post('/auth/logout/adm',           verifyTokenMiddleware, logoutADM)

// ── Auth Cliente ──────────────────────────────────────────────────────────────
r.post('/auth/register/cliente',         registerClient)
r.post('/auth/login/cliente',            loginClient)
r.post('/auth/verify-otp/cliente',       verifyOTPClient)
r.post('/auth/forgot-password/cliente',  forgotPasswordClient)
r.post('/auth/reset-password/cliente',   resetPasswordClient) // ← NOVO (2ª etapa)
r.post('/auth/logout/cliente',           verifyTokenMiddleware, logoutClient)

// ── Auth Fornecedor ───────────────────────────────────────────────────────────
r.post('/auth/register/fornecedor',         registerFornecedor)
r.post('/auth/login/fornecedor',            loginFornecedor)
r.post('/auth/verify-otp/fornecedor',       verifyOTPFornecedor)
r.post('/auth/forgot-password/fornecedor',  forgotPasswordFornecedor)
r.post('/auth/reset-password/fornecedor',   resetPasswordFornecedor) // ← NOVO (2ª etapa)
r.post('/auth/logout/fornecedor',           verifyTokenMiddleware, logoutFornecedor)

// ── Perfil do usuário logado ──────────────────────────────────────────────────
r.get('/adm/profile',        verifyTokenMiddleware, profileADM)
r.put('/adm/me',             verifyTokenMiddleware, updateMeADM)

r.get('/cliente/profile',    verifyTokenMiddleware, profileClient)
r.put('/cliente/me',         verifyTokenMiddleware, upload.single('image'), updateMeClient)

r.get('/fornecedor/profile', verifyTokenMiddleware, profileFornecedor)
r.put('/fornecedor/me',      verifyTokenMiddleware, updateMeFornecedor)

// ── CRUD ADM ──────────────────────────────────────────────────────────────────
r.get('/adm',           getUsersADM)
r.get('/adm/:ra',       verifyTokenMiddleware, getADMByRA)
r.post('/adm',          verifyTokenMiddleware, upload.single('image'), createUserADM)
r.put('/adm/:ra',       verifyTokenMiddleware, upload.single('image'), updateUserADM)
r.delete('/adm/:ra',    verifyTokenMiddleware, deleteUserADM)

// ── CRUD Cliente ──────────────────────────────────────────────────────────────
r.get('/cliente',           getUsersClient)
r.get('/cliente/:idc',      verifyTokenMiddleware, getClientByID)
r.post('/cliente',          verifyTokenMiddleware, upload.single('image'), createUserClient)
r.put('/cliente/:idc',      verifyTokenMiddleware, upload.single('image'), updateUserClient)
r.delete('/cliente/:idc',   verifyTokenMiddleware, deleteUserClient)

// ── CRUD Fornecedor ───────────────────────────────────────────────────────────
r.get('/fornecedor',          getUsersFornecedor)
r.get('/fornecedor/:idf',     verifyTokenMiddleware, getFornecedorByID)
r.post('/fornecedor',         verifyTokenMiddleware, upload.single('image'), createUserFornecedor)
r.put('/fornecedor/:idf',     verifyTokenMiddleware, upload.single('image'), updateUserFornecedor)
r.delete('/fornecedor/:idf',  verifyTokenMiddleware, deleteUserFornecedor)

// ── Produtos ──────────────────────────────────────────────────────────────────
r.get('/produto',          getProdutos)
r.get('/produto/:id',      getProdutoById)
r.post('/produto',         verifyTokenMiddleware, upload.array('images', 5), createProduto)
r.put('/produto/:id',      verifyTokenMiddleware, upload.array('images', 5), updateProdutoFornecedor)
r.delete('/produto/:id',   verifyTokenMiddleware, deleteProdutoFornecedor)

// ── Avaliações ────────────────────────────────────────────────────────────────
r.get('/produto/:id/avaliacoes',  listarAvaliacoes)
r.post('/avaliacoes',             verifyTokenMiddleware, criarAvaliacao)
r.delete('/avaliacoes/:id',       verifyTokenMiddleware, excluirAvaliacao)

// ── Admin Dashboard ───────────────────────────────────────────────────────────
r.get('/admin/clientes',          verifyTokenMiddleware, verifyADM, getAllClientes)
r.get('/admin/clientes/:idc',     verifyTokenMiddleware, verifyADM, getClienteById)
r.put('/admin/clientes/:idc',     verifyTokenMiddleware, verifyADM, updateCliente)
r.delete('/admin/clientes/:idc',  verifyTokenMiddleware, verifyADM, deleteCliente)

r.get('/admin/fornecedores',          verifyTokenMiddleware, verifyADM, getAllFornecedores)
r.get('/admin/fornecedores/:idf',     verifyTokenMiddleware, verifyADM, getFornecedorById)
r.put('/admin/fornecedores/:idf',     verifyTokenMiddleware, verifyADM, updateFornecedor)
r.delete('/admin/fornecedores/:idf',  verifyTokenMiddleware, verifyADM, deleteFornecedor)

r.get('/admin/produtos',          verifyTokenMiddleware, verifyADM, getAllProdutos)
r.get('/admin/produtos/:id',      verifyTokenMiddleware, verifyADM, getProdutoByIdAdmin)
r.put('/admin/produtos/:id',      verifyTokenMiddleware, verifyADM, updateProdutoAdmin)
r.delete('/admin/produtos/:id',   verifyTokenMiddleware, verifyADM, deleteProdutoAdmin)

export default r
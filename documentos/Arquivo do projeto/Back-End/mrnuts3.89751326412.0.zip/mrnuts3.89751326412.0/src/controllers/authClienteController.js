import { pool } from '../db.js'
import bcrypt from 'bcrypt'
import { createToken, denyToken } from '../services/tokenService.js'

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const sanitizeClient = (u) => ({
    idc: u.idc, name: u.name, email: u.email, telefone: u.telefone, img: u.img || null
})

// ── Registro ──────────────────────────────────────────────────────────────────
export async function registerClient(req, res) {
    const { name, email, telefone, password } = req.body
    if (!name || !email || !telefone || !password)
        return res.status(400).json({ error: 'Name, email, telefone e password são obrigatórios' })
    if (!emailRegex.test(email))
        return res.status(400).json({ error: 'Email inválido' })
    try {
        const hash = await bcrypt.hash(password, 10)
        const [result] = await pool.query(
            'INSERT INTO cliente (name, email, telefone, password) VALUES(?, ?, ?, ?)',
            [name, email, telefone, hash]
        )
        res.status(201).json({ idc: result.insertId, name, email, telefone })
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Email já cadastrado' })
        res.status(500).json({ error: 'Erro ao registrar o Cliente' })
    }
}

// ── Login — 1ª etapa: valida credenciais e gera OTP ──────────────────────────
export async function loginClient(req, res) {
    const { email, password } = req.body
    if (!email || !password)
        return res.status(400).json({ error: 'Email e password são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM cliente WHERE email = ?', [email])
        if (!rows.length)
            return res.status(401).json({ error: 'Credenciais inválidas' })
        const cliente = rows[0]
        const match = await bcrypt.compare(password, cliente.password)
        if (!match)
            return res.status(401).json({ error: 'Credenciais inválidas' })

        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpires = new Date(Date.now() + 5 * 60 * 1000)
        await pool.query(
            'UPDATE cliente SET otp_code = ?, otp_expires = ? WHERE idc = ?',
            [otp, otpExpires, cliente.idc]
        )

        console.log(`[2FA] OTP para cliente ${cliente.email}: ${otp}`)

        res.json({ requiresOTP: true, idc: cliente.idc, message: 'Código enviado. Verifique o console do servidor (dev).' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro no login' })
    }
}

// ── Login — 2ª etapa: verifica OTP e retorna token ───────────────────────────
export async function verifyOTPClient(req, res) {
    const { idc, otp } = req.body
    if (!idc || !otp)
        return res.status(400).json({ error: 'idc e otp são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM cliente WHERE idc = ?', [idc])
        if (!rows.length)
            return res.status(404).json({ error: 'Usuário não encontrado' })
        const cliente = rows[0]

        if (!cliente.otp_code || !cliente.otp_expires)
            return res.status(400).json({ error: 'Nenhum código pendente. Faça login novamente.' })
        if (new Date() > new Date(cliente.otp_expires))
            return res.status(401).json({ error: 'Código expirado. Faça login novamente.' })
        if (cliente.otp_code !== otp)
            return res.status(401).json({ error: 'Código incorreto' })

        await pool.query('UPDATE cliente SET otp_code = NULL, otp_expires = NULL WHERE idc = ?', [idc])

        const { token } = createToken({ idc: cliente.idc })
        res.json({ token, cliente: sanitizeClient(cliente) })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro ao verificar código' })
    }
}

// ── Logout ────────────────────────────────────────────────────────────────────
export async function logoutClient(req, res) {
    try {
        denyToken(req.cliente?.jti || req.user?.jti)
        res.json({ message: 'Logout realizado com sucesso' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro no logout' })
    }
}

// ── Esqueci a senha — 1ª etapa: gera OTP ─────────────────────────────────────
export async function forgotPasswordClient(req, res) {
    const { email } = req.body
    if (!email)
        return res.status(400).json({ error: 'email é obrigatório' })
    try {
        const [rows] = await pool.query('SELECT idc FROM cliente WHERE email = ?', [email])

        if (!rows.length)
            return res.json({ message: 'Se o email existir, um código foi enviado.' })

        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpires = new Date(Date.now() + 5 * 60 * 1000)
        await pool.query(
            'UPDATE cliente SET otp_code = ?, otp_expires = ? WHERE email = ?',
            [otp, otpExpires, email]
        )

        console.log(`[Reset Cliente] OTP para ${email}: ${otp}`)
        res.json({ message: 'Se o email existir, um código foi enviado.', idc: rows[0].idc })
    } catch {
        res.status(500).json({ error: 'Erro ao solicitar redefinição de senha' })
    }
}

// ── Esqueci a senha — 2ª etapa: verifica OTP e redefine senha ────────────────
export async function resetPasswordClient(req, res) {
    const { idc, otp, newPassword } = req.body
    if (!idc || !otp || !newPassword)
        return res.status(400).json({ error: 'idc, otp e newPassword são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM cliente WHERE idc = ?', [idc])
        if (!rows.length)
            return res.status(404).json({ error: 'Cliente não encontrado' })
        const cliente = rows[0]

        if (!cliente.otp_code || !cliente.otp_expires)
            return res.status(400).json({ error: 'Nenhum código pendente. Solicite a redefinição novamente.' })
        if (new Date() > new Date(cliente.otp_expires))
            return res.status(401).json({ error: 'Código expirado. Solicite novamente.' })
        if (cliente.otp_code !== otp)
            return res.status(401).json({ error: 'Código incorreto' })

        const hash = await bcrypt.hash(newPassword, 10)
        await pool.query(
            'UPDATE cliente SET password = ?, otp_code = NULL, otp_expires = NULL WHERE idc = ?',
            [hash, idc]
        )
        res.json({ message: 'Senha redefinida com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao redefinir senha' })
    }
}
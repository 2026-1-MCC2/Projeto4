import { pool } from '../db.js'
import bcrypt from 'bcrypt'
import { createToken, denyToken } from '../services/tokenService.js'

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const sanitizeADM = (u) => ({
    ra: u.ra, name: u.name, email: u.email, telefone: u.telefone
})

// ── Registro ──────────────────────────────────────────────────────────────────
export async function registerADM(req, res) {
    const { name, email, telefone, password } = req.body
    if (!name || !email || !telefone || !password)
        return res.status(400).json({ error: 'Name, email, telefone e password são obrigatórios' })
    if (!emailRegex.test(email))
        return res.status(400).json({ error: 'Email inválido' })
    try {
        const hash = await bcrypt.hash(password, 10)
        const [result] = await pool.query(
            'INSERT INTO adm (name, email, telefone, password) VALUES(?, ?, ?, ?)',
            [name, email, telefone, hash]
        )
        res.status(201).json({ ra: result.insertId, name, email, telefone })
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Email já cadastrado' })
        res.status(500).json({ error: 'Erro ao registrar o Administrador' })
    }
}

// ── Login — 1ª etapa: valida credenciais e gera OTP ──────────────────────────
export async function loginADM(req, res) {
    const { email, password } = req.body
    if (!email || !password)
        return res.status(400).json({ error: 'Email e password são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM adm WHERE email = ?', [email])
        if (!rows.length)
            return res.status(401).json({ error: 'Credenciais inválidas' })
        const adm = rows[0]
        const match = await bcrypt.compare(password, adm.password)
        if (!match)
            return res.status(401).json({ error: 'Credenciais inválidas' })

        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpires = new Date(Date.now() + 5 * 60 * 1000)
        await pool.query(
            'UPDATE adm SET otp_code = ?, otp_expires = ? WHERE ra = ?',
            [otp, otpExpires, adm.ra]
        )

        // Em produção: enviar por email/SMS. Em dev, loga no console.
        console.log(`[2FA] OTP para admin ${adm.email}: ${otp}`)

        res.json({ requiresOTP: true, ra: adm.ra, message: 'Código enviado. Verifique o console do servidor (dev).' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro no login' })
    }
}

// ── Login — 2ª etapa: verifica OTP e retorna token ───────────────────────────
export async function verifyOTPADM(req, res) {
    const { ra, otp } = req.body
    if (!ra || !otp)
        return res.status(400).json({ error: 'ra e otp são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM adm WHERE ra = ?', [ra])
        if (!rows.length)
            return res.status(404).json({ error: 'Administrador não encontrado' })
        const adm = rows[0]

        if (!adm.otp_code || !adm.otp_expires)
            return res.status(400).json({ error: 'Nenhum código pendente. Faça login novamente.' })
        if (new Date() > new Date(adm.otp_expires))
            return res.status(401).json({ error: 'Código expirado. Faça login novamente.' })
        if (adm.otp_code !== otp)
            return res.status(401).json({ error: 'Código incorreto' })

        await pool.query('UPDATE adm SET otp_code = NULL, otp_expires = NULL WHERE ra = ?', [ra])

        const { token } = createToken({ ra: adm.ra })
        res.json({ token, adm: sanitizeADM(adm) })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro ao verificar código' })
    }
}

// ── Logout ────────────────────────────────────────────────────────────────────
export async function logoutADM(req, res) {
    try {
        denyToken(req.adm?.jti || req.user?.jti)
        res.json({ message: 'Logout realizado com sucesso' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro no logout' })
    }
}

// ── Esqueci a senha — 1ª etapa: gera OTP ─────────────────────────────────────
export async function forgotPasswordADM(req, res) {
    const { email } = req.body
    if (!email)
        return res.status(400).json({ error: 'email é obrigatório' })
    try {
        const [rows] = await pool.query('SELECT ra FROM adm WHERE email = ?', [email])

        // Não revela se o email existe
        if (!rows.length)
            return res.json({ message: 'Se o email existir, um código foi enviado.' })

        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpires = new Date(Date.now() + 5 * 60 * 1000)
        await pool.query(
            'UPDATE adm SET otp_code = ?, otp_expires = ? WHERE email = ?',
            [otp, otpExpires, email]
        )

        console.log(`[Reset ADM] OTP para ${email}: ${otp}`)
        res.json({ message: 'Se o email existir, um código foi enviado.', ra: rows[0].ra })
    } catch {
        res.status(500).json({ error: 'Erro ao solicitar redefinição de senha' })
    }
}

// ── Esqueci a senha — 2ª etapa: verifica OTP e redefine senha ────────────────
export async function resetPasswordADM(req, res) {
    const { ra, otp, newPassword } = req.body
    if (!ra || !otp || !newPassword)
        return res.status(400).json({ error: 'ra, otp e newPassword são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM adm WHERE ra = ?', [ra])
        if (!rows.length)
            return res.status(404).json({ error: 'Administrador não encontrado' })
        const adm = rows[0]

        if (!adm.otp_code || !adm.otp_expires)
            return res.status(400).json({ error: 'Nenhum código pendente. Solicite a redefinição novamente.' })
        if (new Date() > new Date(adm.otp_expires))
            return res.status(401).json({ error: 'Código expirado. Solicite novamente.' })
        if (adm.otp_code !== otp)
            return res.status(401).json({ error: 'Código incorreto' })

        const hash = await bcrypt.hash(newPassword, 10)
        await pool.query(
            'UPDATE adm SET password = ?, otp_code = NULL, otp_expires = NULL WHERE ra = ?',
            [hash, ra]
        )
        res.json({ message: 'Senha redefinida com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao redefinir senha' })
    }
}
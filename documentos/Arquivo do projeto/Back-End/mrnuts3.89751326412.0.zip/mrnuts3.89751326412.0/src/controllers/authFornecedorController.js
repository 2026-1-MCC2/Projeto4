import { pool } from '../db.js'
import bcrypt from 'bcrypt'
import { createToken, denyToken } from '../services/tokenService.js'

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const sanitizeFornecedor = (u) => ({
    idf: u.id_fornecedor, name: u.name, cnpj: u.cnpj, email: u.email, img: u.img || null
})

// ── Registro ──────────────────────────────────────────────────────────────────
export async function registerFornecedor(req, res) {
    const { name, cnpj, email, password } = req.body
    if (!name || !cnpj || !email || !password)
        return res.status(400).json({ error: 'Name, cnpj, email e password são obrigatórios' })
    if (!emailRegex.test(email))
        return res.status(400).json({ error: 'Email inválido' })
    try {
        const hash = await bcrypt.hash(password, 10)
        const [result] = await pool.query(
            'INSERT INTO fornecedor (name, cnpj, email, password) VALUES(?, ?, ?, ?)',
            [name, cnpj, email, hash]
        )
        res.status(201).json({ idf: result.insertId, name, cnpj, email })
    } catch (err) {
        if (err.code === 'ER_DUP_ENTRY')
            return res.status(409).json({ error: 'Email ou CNPJ já cadastrado' })
        res.status(500).json({ error: 'Erro ao registrar o Fornecedor' })
    }
}

// ── Login — 1ª etapa: valida credenciais e gera OTP ──────────────────────────
export async function loginFornecedor(req, res) {
    const { email, password } = req.body
    if (!email || !password)
        return res.status(400).json({ error: 'Email e password são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM fornecedor WHERE email = ?', [email])
        if (!rows.length)
            return res.status(401).json({ error: 'Credenciais inválidas' })
        const fornecedor = rows[0]
        const match = await bcrypt.compare(password, fornecedor.password)
        if (!match)
            return res.status(401).json({ error: 'Credenciais inválidas' })

        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpires = new Date(Date.now() + 5 * 60 * 1000)
        await pool.query(
            'UPDATE fornecedor SET otp_code = ?, otp_expires = ? WHERE id_fornecedor = ?',
            [otp, otpExpires, fornecedor.id_fornecedor]
        )

        console.log(`[2FA] OTP para fornecedor ${fornecedor.email}: ${otp}`)

        res.json({ requiresOTP: true, idf: fornecedor.id_fornecedor, message: 'Código enviado. Verifique o console do servidor (dev).' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro no login' })
    }
}

// ── Login — 2ª etapa: verifica OTP e retorna token ───────────────────────────
export async function verifyOTPFornecedor(req, res) {
    const { idf, otp } = req.body
    if (!idf || !otp)
        return res.status(400).json({ error: 'idf e otp são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (!rows.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        const fornecedor = rows[0]

        if (!fornecedor.otp_code || !fornecedor.otp_expires)
            return res.status(400).json({ error: 'Nenhum código pendente. Faça login novamente.' })
        if (new Date() > new Date(fornecedor.otp_expires))
            return res.status(401).json({ error: 'Código expirado. Faça login novamente.' })
        if (fornecedor.otp_code !== otp)
            return res.status(401).json({ error: 'Código incorreto' })

        await pool.query('UPDATE fornecedor SET otp_code = NULL, otp_expires = NULL WHERE id_fornecedor = ?', [idf])

        const { token } = createToken({ idf: fornecedor.id_fornecedor })
        res.json({ token, fornecedor: sanitizeFornecedor(fornecedor) })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro ao verificar código' })
    }
}

// ── Logout ────────────────────────────────────────────────────────────────────
export async function logoutFornecedor(req, res) {
    try {
        denyToken(req.fornecedor?.jti || req.user?.jti)
        res.json({ message: 'Logout realizado com sucesso' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ error: 'Erro no logout' })
    }
}

// ── Esqueci a senha — 1ª etapa: gera OTP ─────────────────────────────────────
export async function forgotPasswordFornecedor(req, res) {
    const { email } = req.body
    if (!email)
        return res.status(400).json({ error: 'email é obrigatório' })
    try {
        const [rows] = await pool.query('SELECT id_fornecedor FROM fornecedor WHERE email = ?', [email])

        if (!rows.length)
            return res.json({ message: 'Se o email existir, um código foi enviado.' })

        const otp = Math.floor(100000 + Math.random() * 900000).toString()
        const otpExpires = new Date(Date.now() + 5 * 60 * 1000)
        await pool.query(
            'UPDATE fornecedor SET otp_code = ?, otp_expires = ? WHERE email = ?',
            [otp, otpExpires, email]
        )

        console.log(`[Reset Fornecedor] OTP para ${email}: ${otp}`)
        res.json({ message: 'Se o email existir, um código foi enviado.', idf: rows[0].id_fornecedor })
    } catch {
        res.status(500).json({ error: 'Erro ao solicitar redefinição de senha' })
    }
}

// ── Esqueci a senha — 2ª etapa: verifica OTP e redefine senha ────────────────
export async function resetPasswordFornecedor(req, res) {
    const { idf, otp, newPassword } = req.body
    if (!idf || !otp || !newPassword)
        return res.status(400).json({ error: 'idf, otp e newPassword são obrigatórios' })
    try {
        const [rows] = await pool.query('SELECT * FROM fornecedor WHERE id_fornecedor = ?', [idf])
        if (!rows.length)
            return res.status(404).json({ error: 'Fornecedor não encontrado' })
        const fornecedor = rows[0]

        if (!fornecedor.otp_code || !fornecedor.otp_expires)
            return res.status(400).json({ error: 'Nenhum código pendente. Solicite a redefinição novamente.' })
        if (new Date() > new Date(fornecedor.otp_expires))
            return res.status(401).json({ error: 'Código expirado. Solicite novamente.' })
        if (fornecedor.otp_code !== otp)
            return res.status(401).json({ error: 'Código incorreto' })

        const hash = await bcrypt.hash(newPassword, 10)
        await pool.query(
            'UPDATE fornecedor SET password = ?, otp_code = NULL, otp_expires = NULL WHERE id_fornecedor = ?',
            [hash, idf]
        )
        res.json({ message: 'Senha redefinida com sucesso' })
    } catch {
        res.status(500).json({ error: 'Erro ao redefinir senha' })
    }
}
/* ════════════════════════════════════════════════════════════════════════════════ */
/* ADMIN DASHBOARD - JAVASCRIPT LOGIC                                               */
/* ════════════════════════════════════════════════════════════════════════════════ */

const API_URL   = 'http://localhost:3000/api'
const token     = localStorage.getItem('token')
const adminUser = JSON.parse(localStorage.getItem('adminUser'))

let appState = {
    currentTab: 'clientes',
    currentEditItem: null,
    currentDeleteItem: null,
    clientes: [],
    fornecedores: [],
    produtos: [],
    filteredData: { clientes: [], fornecedores: [], produtos: [] }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── TOAST
// ════════════════════════════════════════════════════════════════════════════════

function showToast(message, type = 'success') {
    let container = document.getElementById('toastContainer')
    if (!container) {
        container = document.createElement('div')
        container.id = 'toastContainer'
        container.style.cssText = `
            position: fixed; top: 20px; right: 20px; z-index: 9999;
            display: flex; flex-direction: column; gap: 8px;
        `
        document.body.appendChild(container)
    }

    const toast = document.createElement('div')
    toast.style.cssText = `
        padding: 12px 20px; border-radius: 8px; color: #fff; font-size: 0.9rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2); opacity: 0;
        transition: opacity 0.3s ease; min-width: 220px;
        background: ${type === 'success' ? '#22c55e' : '#ef4444'};
    `
    toast.textContent = message
    container.appendChild(toast)

    requestAnimationFrame(() => { toast.style.opacity = '1' })
    setTimeout(() => {
        toast.style.opacity = '0'
        setTimeout(() => toast.remove(), 300)
    }, 3500)
}

function showSuccess(message) { showToast(message, 'success') }
function showError(message)   { showToast(message, 'error') }

// ════════════════════════════════════════════════════════════════════════════════
// ──── INICIALIZAÇÃO
// ════════════════════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', async () => {
    if (!token || !adminUser) {
        window.location.href = 'admin-login.html'
        return
    }
    initializeUI()
    await Promise.all([loadClientes(), loadFornecedores(), loadProdutos()])
    setupEventListeners()
})

function initializeUI() {
    document.getElementById('adminName').textContent   = adminUser.name || 'Admin'
    document.getElementById('adminAvatar').textContent = (adminUser.name || 'A').charAt(0).toUpperCase()
}

function setupEventListeners() {
    document.querySelectorAll('[data-tab]').forEach(tab => {
        tab.addEventListener('click', (e) => { e.preventDefault(); switchTab(tab.dataset.tab) })
    })
    document.getElementById('logoutBtn').addEventListener('click', logout)
    document.getElementById('searchClientes').addEventListener('input', filterClientes)
    document.getElementById('searchFornecedores').addEventListener('input', filterFornecedores)
    document.getElementById('searchProdutos').addEventListener('input', filterProdutos)
    document.getElementById('closeModalBtn').addEventListener('click', closeEditModal)
    document.getElementById('cancelEditBtn').addEventListener('click', closeEditModal)
    document.getElementById('saveEditBtn').addEventListener('click', saveEdit)
    document.getElementById('closeDeleteModalBtn').addEventListener('click', closeDeleteModal)
    document.getElementById('cancelDeleteBtn').addEventListener('click', closeDeleteModal)
    document.getElementById('confirmDeleteBtn').addEventListener('click', confirmDelete)
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── NAVIGATION
// ════════════════════════════════════════════════════════════════════════════════

function switchTab(tab) {
    document.querySelectorAll('.admin-tab-content').forEach(c => c.classList.remove('active'))
    document.querySelectorAll('.admin-sidebar-link').forEach(l => l.classList.remove('active'))
    document.getElementById(tab).classList.add('active')
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active')
    appState.currentTab = tab
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── CLIENTES
// ════════════════════════════════════════════════════════════════════════════════

async function loadClientes() {
    try {
        const res = await fetch(`${API_URL}/admin/clientes`, {
            headers: { 'Authorization': `Bearer ${token}` }
        })
        if (!res.ok) throw new Error()
        appState.clientes = await res.json()
        appState.filteredData.clientes = appState.clientes
        renderClientesTable()
    } catch {
        showError('Erro ao carregar clientes')
    }
}

function renderClientesTable() {
    const tbody = document.getElementById('clientesTableBody')
    if (!appState.filteredData.clientes.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:40px;">Nenhum cliente encontrado</td></tr>'
        return
    }
    tbody.innerHTML = appState.filteredData.clientes.map(c => `
        <tr>
            <td>${c.idc}</td>
            <td>${escHtml(c.name)}</td>
            <td>${escHtml(c.email)}</td>
            <td>${escHtml(c.telefone)}</td>
            <td>${formatDate(c.created_at)}</td>
            <td>
                <div class="admin-action-buttons">
                    <button class="btn-edit"   onclick="openEditClienteModal(${c.idc})">Editar</button>
                    <button class="btn-delete" onclick="openDeleteModal('cliente', ${c.idc})">Deletar</button>
                </div>
            </td>
        </tr>
    `).join('')
}

function filterClientes() {
    const s = document.getElementById('searchClientes').value.toLowerCase()
    appState.filteredData.clientes = appState.clientes.filter(c =>
        c.name.toLowerCase().includes(s) || c.email.toLowerCase().includes(s)
    )
    renderClientesTable()
}

function openEditClienteModal(idc) {
    const c = appState.clientes.find(x => x.idc === idc)
    if (!c) return
    appState.currentEditItem = { type: 'cliente', data: c }
    document.getElementById('modalTitle').textContent = 'Editar Cliente'
    document.getElementById('editForm').innerHTML = `
        <div class="form-group"><label>Nome</label>
            <input type="text" id="editName" value="${escHtml(c.name)}" required></div>
        <div class="form-group"><label>Email</label>
            <input type="email" id="editEmail" value="${escHtml(c.email)}" required></div>
        <div class="form-group"><label>Telefone</label>
            <input type="tel" id="editTelefone" value="${escHtml(c.telefone)}" required></div>
    `
    document.getElementById('editModal').classList.add('active')
}

async function updateCliente(idc) {
    const name     = document.getElementById('editName').value.trim()
    const email    = document.getElementById('editEmail').value.trim()
    const telefone = document.getElementById('editTelefone').value.trim()
    if (!name || !email || !telefone) { showError('Todos os campos são obrigatórios'); return false }
    try {
        const res = await fetch(`${API_URL}/admin/clientes/${idc}`, {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, telefone })
        })
        const data = await res.json()
        if (!res.ok) { showError(data.error || 'Erro ao atualizar cliente'); return false }
        await loadClientes()
        return true
    } catch {
        showError('Erro ao atualizar cliente')
        return false
    }
}

async function deleteCliente(idc) {
    try {
        const res = await fetch(`${API_URL}/admin/clientes/${idc}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        })
        const data = await res.json()
        if (!res.ok) { showError(data.error || 'Erro ao deletar cliente'); return false }
        await loadClientes()
        return true
    } catch {
        showError('Erro ao deletar cliente')
        return false
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── FORNECEDORES
// ════════════════════════════════════════════════════════════════════════════════

async function loadFornecedores() {
    try {
        const res = await fetch(`${API_URL}/admin/fornecedores`, {
            headers: { 'Authorization': `Bearer ${token}` }
        })
        if (!res.ok) throw new Error()
        appState.fornecedores = await res.json()
        appState.filteredData.fornecedores = appState.fornecedores
        renderFornecedoresTable()
    } catch {
        showError('Erro ao carregar fornecedores')
    }
}

function renderFornecedoresTable() {
    const tbody = document.getElementById('fornecedoresTableBody')
    if (!appState.filteredData.fornecedores.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:40px;">Nenhum fornecedor encontrado</td></tr>'
        return
    }
    tbody.innerHTML = appState.filteredData.fornecedores.map(f => `
        <tr>
            <td>${f.id_fornecedor}</td>
            <td>${escHtml(f.name)}</td>
            <td>${escHtml(f.cnpj)}</td>
            <td>${escHtml(f.email)}</td>
            <td>${formatDate(f.created_at)}</td>
            <td>
                <div class="admin-action-buttons">
                    <button class="btn-edit"   onclick="openEditFornecedorModal(${f.id_fornecedor})">Editar</button>
                    <button class="btn-delete" onclick="openDeleteModal('fornecedor', ${f.id_fornecedor})">Deletar</button>
                </div>
            </td>
        </tr>
    `).join('')
}

function filterFornecedores() {
    const s = document.getElementById('searchFornecedores').value.toLowerCase()
    appState.filteredData.fornecedores = appState.fornecedores.filter(f =>
        f.name.toLowerCase().includes(s) ||
        f.cnpj.toLowerCase().includes(s) ||
        f.email.toLowerCase().includes(s)
    )
    renderFornecedoresTable()
}

function openEditFornecedorModal(idf) {
    const f = appState.fornecedores.find(x => x.id_fornecedor === idf)
    if (!f) return
    appState.currentEditItem = { type: 'fornecedor', data: f }
    document.getElementById('modalTitle').textContent = 'Editar Fornecedor'
    document.getElementById('editForm').innerHTML = `
        <div class="form-group"><label>Nome</label>
            <input type="text" id="editName" value="${escHtml(f.name)}" required></div>
        <div class="form-group"><label>CNPJ</label>
            <input type="text" id="editCnpj" value="${escHtml(f.cnpj)}" required></div>
        <div class="form-group"><label>Email</label>
            <input type="email" id="editEmail" value="${escHtml(f.email)}" required></div>
    `
    document.getElementById('editModal').classList.add('active')
}

async function updateFornecedor(idf) {
    const name  = document.getElementById('editName').value.trim()
    const cnpj  = document.getElementById('editCnpj').value.trim()
    const email = document.getElementById('editEmail').value.trim()
    if (!name || !cnpj || !email) { showError('Todos os campos são obrigatórios'); return false }
    try {
        const res = await fetch(`${API_URL}/admin/fornecedores/${idf}`, {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, cnpj, email })
        })
        const data = await res.json()
        if (!res.ok) { showError(data.error || 'Erro ao atualizar fornecedor'); return false }
        await loadFornecedores()
        return true
    } catch {
        showError('Erro ao atualizar fornecedor')
        return false
    }
}

async function deleteFornecedor(idf) {
    try {
        const res = await fetch(`${API_URL}/admin/fornecedores/${idf}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        })
        const data = await res.json()
        if (!res.ok) { showError(data.error || 'Erro ao deletar fornecedor'); return false }
        await loadFornecedores()
        await loadProdutos() // produtos deste fornecedor foram deletados em cascata
        return true
    } catch {
        showError('Erro ao deletar fornecedor')
        return false
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── PRODUTOS
// ════════════════════════════════════════════════════════════════════════════════

async function loadProdutos() {
    try {
        const res = await fetch(`${API_URL}/admin/produtos`, {
            headers: { 'Authorization': `Bearer ${token}` }
        })
        if (!res.ok) throw new Error()
        appState.produtos = await res.json()
        appState.filteredData.produtos = appState.produtos
        renderProdutosTable()
    } catch {
        showError('Erro ao carregar produtos')
    }
}

function renderProdutosTable() {
    const tbody = document.getElementById('produtosTableBody')
    if (!appState.filteredData.produtos.length) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:40px;">Nenhum produto encontrado</td></tr>'
        return
    }
    tbody.innerHTML = appState.filteredData.produtos.map(p => `
        <tr>
            <td>${p.Cod_produto}</td>
            <td>${escHtml(p.Titulo)}</td>
            <td>${escHtml(p.Categoria)}</td>
            <td>${p.Preco != null ? 'R$ ' + parseFloat(p.Preco).toFixed(2) : '—'}</td>
            <td>${escHtml(p.fornecedor_nome || String(p.id_fornecedor))}</td>
            <td>${formatDate(p.created_at)}</td>
            <td>
                <div class="admin-action-buttons">
                    <button class="btn-edit"   onclick="openEditProdutoModal(${p.Cod_produto})">Editar</button>
                    <button class="btn-delete" onclick="openDeleteModal('produto', ${p.Cod_produto})">Deletar</button>
                </div>
            </td>
        </tr>
    `).join('')
}

function filterProdutos() {
    const s = document.getElementById('searchProdutos').value.toLowerCase()
    appState.filteredData.produtos = appState.produtos.filter(p =>
        p.Titulo.toLowerCase().includes(s) || p.Categoria.toLowerCase().includes(s)
    )
    renderProdutosTable()
}

function openEditProdutoModal(codProduto) {
    const p = appState.produtos.find(x => x.Cod_produto === codProduto)
    if (!p) return
    appState.currentEditItem = { type: 'produto', data: p }
    document.getElementById('modalTitle').textContent = 'Editar Produto'
    const cats = ['nozes','castanhas','grãos','sementes','farináceos','chips','temperos']
    const opts = cats.map(c => `<option value="${c}" ${p.Categoria === c ? 'selected' : ''}>${c.charAt(0).toUpperCase()+c.slice(1)}</option>`).join('')
    document.getElementById('editForm').innerHTML = `
        <div class="form-group"><label>Título</label>
            <input type="text" id="editTitulo" value="${escHtml(p.Titulo)}" required></div>
        <div class="form-group"><label>Descrição</label>
            <textarea id="editDescricao" rows="3">${escHtml(p.Descricao || '')}</textarea></div>
        <div class="form-group"><label>Categoria</label>
            <select id="editCategoria" required>${opts}</select></div>
        <div class="form-group"><label>Preço</label>
            <input type="number" id="editPreco" value="${p.Preco || ''}" step="0.01" min="0"></div>
    `
    document.getElementById('editModal').classList.add('active')
}

async function updateProduto(codProduto) {
    const Titulo    = document.getElementById('editTitulo').value.trim()
    const Descricao = document.getElementById('editDescricao').value.trim()
    const Categoria = document.getElementById('editCategoria').value
    const Preco     = document.getElementById('editPreco').value
    if (!Titulo || !Categoria) { showError('Título e categoria são obrigatórios'); return false }
    try {
        const res = await fetch(`${API_URL}/admin/produtos/${codProduto}`, {
            method: 'PUT',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ Titulo, Descricao: Descricao || null, Categoria, Preco: Preco ? parseFloat(Preco) : null })
        })
        const data = await res.json()
        if (!res.ok) { showError(data.error || 'Erro ao atualizar produto'); return false }
        await loadProdutos()
        return true
    } catch {
        showError('Erro ao atualizar produto')
        return false
    }
}

async function deleteProduto(codProduto) {
    try {
        const res = await fetch(`${API_URL}/admin/produtos/${codProduto}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        })
        const data = await res.json()
        if (!res.ok) { showError(data.error || 'Erro ao deletar produto'); return false }
        await loadProdutos()
        return true
    } catch {
        showError('Erro ao deletar produto')
        return false
    }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── MODALS
// ════════════════════════════════════════════════════════════════════════════════

function closeEditModal() {
    document.getElementById('editModal').classList.remove('active')
    appState.currentEditItem = null
}

async function saveEdit() {
    if (!appState.currentEditItem) return
    const { type, data } = appState.currentEditItem
    let success = false
    if      (type === 'cliente')    success = await updateCliente(data.idc)
    else if (type === 'fornecedor') success = await updateFornecedor(data.id_fornecedor)
    else if (type === 'produto')    success = await updateProduto(data.Cod_produto)
    if (success) { closeEditModal(); showSuccess('Alterações salvas com sucesso!') }
}

function openDeleteModal(type, id) {
    appState.currentDeleteItem = { type, id }
    const msgs = {
        cliente:     'Tem certeza que deseja deletar este cliente?',
        fornecedor:  'Tem certeza que deseja deletar este fornecedor? Todos os seus produtos e avaliações também serão deletados.',
        produto:     'Tem certeza que deseja deletar este produto? As avaliações associadas também serão deletadas.'
    }
    document.getElementById('deleteMessage').textContent = (msgs[type] || '') + ' Esta ação não pode ser desfeita.'
    document.getElementById('deleteModal').classList.add('active')
}

function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active')
    appState.currentDeleteItem = null
}

async function confirmDelete() {
    if (!appState.currentDeleteItem) return
    const { type, id } = appState.currentDeleteItem
    let success = false
    if      (type === 'cliente')    success = await deleteCliente(id)
    else if (type === 'fornecedor') success = await deleteFornecedor(id)
    else if (type === 'produto')    success = await deleteProduto(id)
    if (success) { closeDeleteModal(); showSuccess('Item deletado com sucesso!') }
}

// ════════════════════════════════════════════════════════════════════════════════
// ──── UTILITIES
// ════════════════════════════════════════════════════════════════════════════════

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('pt-BR', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit'
    })
}

// Previne XSS ao inserir strings no HTML
function escHtml(str) {
    if (str == null) return ''
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
}

async function logout() {
    try {
        await fetch(`${API_URL}/auth/logout/adm`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` }
        })
    } catch { /* ignora erros de rede no logout */ }
    localStorage.removeItem('token')
    localStorage.removeItem('adminUser')
    window.location.href = 'admin-login.html'
}
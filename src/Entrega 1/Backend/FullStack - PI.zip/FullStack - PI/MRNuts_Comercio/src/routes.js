import { Router } from 'express'
//ADM
import {
    getUsersADM, createUserADM, getADMByRA, deleteUserADM, updateUserADM, 
} from './controllers/ADMController.js'

const r = Router()

r.get('/adm', getUsersADM)
r.post('/adm', createUserADM)
r.get('/adm/:ra', getADMByRA)
r.delete('/adm/:ra', deleteUserADM)
r.put('/adm/:ra', updateUserADM)


import {
    getUsersFornecedor, createUserFornecedor, getFornecedorByID, deleteUserFornecedor, updateUserFornecedor
} from './controllers/FornecedorController.js'

r.get('/fornecedor', getUsersFornecedor)
r.post('/fornecedor', createUserFornecedor)
r.get('/fornecedor/:idf', getFornecedorByID)
r.delete('/fornecedor/:idf', deleteUserFornecedor)
r.put('/fornecedor/:idf', updateUserFornecedor)


import {
    getUsersClient, createUserClient, getClientByID, deleteUserClient, updateUserClient
} from './controllers/ClienteController.js'

r.get('/cliente', getUsersClient)
r.post('/cliente', createUserClient)
r.get('/cliente/:idc', getClientByID)
r.delete('/cliente/:idc', deleteUserClient)
r.put('/cliente/:idc', updateUserClient)

export default r
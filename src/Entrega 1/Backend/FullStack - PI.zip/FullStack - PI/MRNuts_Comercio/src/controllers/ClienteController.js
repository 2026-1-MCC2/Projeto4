import {pool} from '../db.js'

//Listar Todos Clientes
export async function getUsersClient(_, res){
    try{
        const [rows] = await pool.query(
            'SELECT idc, name, email, telefone, senha, created_at FROM cliente ORDER BY idc DESC'
        )
        res.json(rows)
    } catch {
        res.status(500).json({error: 'Erro ao listar users Cliente'})
    }
}
//Criar Usuário Cliente
export async function createUserClient(req, res){
    const {name, email, telefone, senha} = req.body
    if(!name || !email || !telefone || !senha){
        return res.status(400).json({error: 'Nome, Email, Telefone e Senha são obrigatórios'})
    }
    try{
        const [result] = await pool.query(
            'INSERT INTO cliente (name, email, telefone, senha) VALUES (?,?,?,?)',
            [name, email, telefone, senha]
        )
        res.status(201).json({idc: result.insertId})
    } catch (err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({error: 'Cliente já cadastrado'})
        }
        res.status(500).json({error: 'Erro ao criar Cliente'})
    }
}

//Buscar por id cliente
//http://localhost:3000/api/cliente/:idc
export async function getClientByID(req, res){
    const {idc} = req.params
    try{
        const [rows] = await pool.query(
            'SELECT idc, name, email, telefone, senha, created_at FROM cliente ORDER BY idc DESC',
            [idc]
        )
        if(rows.length === 0){
            return res.status(404).json({error: 'Cliente não encontrado'})
        }
        res.json(rows[0])
    } catch {
        res.status(500).json({error: 'Erro ao Buscar Cliente'})
    }
}

//Rota do Tipo DELETE cliente
//http://localhost:3000/api/cliente/:idc
export async function deleteUserClient(req, res){
    const {idc} = req.params
    try{
        const[result] = await pool.query(
            'DELETE FROM cliente WHERE idc =?',
            [idc]
        )
        if(result.affectedRows === 0){
            return res.status(404).json({error:'Cliente não encontrado!'})
        }
        res.json({message:'Cliente excluído com sucesso'})
    } catch {
        res.status(500).json({error:'Erro ao excluir Cliente'})
    }
}
//Rota do Tipo PUT cliente
//http://localhost:3000/api/cliente/:idc
export async function updateUserClient(req, res){
    const {idc} = req.params
    const {name, email, telefone, senha} = req.body
    if(!name || !email || !telefone || !senha){
        return res.status(400).json({error:'Nome, Email, Telefone e Senha são obrigatórios'})
    }
    try{
        const[result] = await pool.query(
            'UPDATE cliente SET name =?, email=?, telefone =?, senha =? WHERE idc=?',
            [name, email, telefone, senha, idc]
        )
        if(result.affectedRows === 0){
            return res.status(404).json({error:'Cliente não encontrado'})
        }
        const[rows] = await pool.query(
            'SELECT idc, name, email, telefone, senha, created_at FROM cliente ORDER BY idc DESC',
            [idc]
        )
        res.json(rows[0])
    } catch(err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({error:'Email já cadastrado'})
        }
        res.status(500).json({error:'Erro ao atualizar o cadastro de Cliente'})
    }
}
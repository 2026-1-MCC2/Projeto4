import {pool} from '../db.js'

//Listar Todos ADM
export async function getUsersADM(_, res){
    try{
        const [rows] = await pool.query(
            'SELECT ra, name, email, telefone, senha, created_at FROM adm ORDER BY ra DESC'
        )
        res.json(rows)
    } catch {
        res.status(500).json({error: 'Erro ao listar users Administrador'})
    }
}
//Criar Usuário ADM
export async function createUserADM(req, res){
    const {name, email, telefone, senha} = req.body
    if(!name || !email || !telefone || !senha){
        return res.status(400).json({error: 'Nome, Email, Telefone e Senha são obrigatórios'})
    }
    try{
        const [result] = await pool.query(
            'INSERT INTO adm (name, email, telefone, senha) VALUES (?,?,?,?)',
            [name, email, telefone, senha]
        )
        res.status(201).json({ra: result.insertId})
    } catch (err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({error: 'Administrador já cadastrado'})
        }
        res.status(500).json({error: 'Erro ao criar Administrador'})
    }
}

//Buscar por RA (ADM)
//http://localhost:3000/api/adm/:id
export async function getADMByRA(req, res){
    const {ra} = req.params
    try{
        const [rows] = await pool.query(
            'SELECT ra, name, email, telefone, senha, created_at FROM adm WHERE ra= ?',
            [ra]
        )
        if(rows.length === 0){
            return res.status(404).json({error: 'Administrador não encontrado'})
        }
        res.json(rows[0])
    } catch {
        res.status(500).json({error: 'Erro ao Buscar Administrador'})
    }
}

//Rota do Tipo DELETE
//http://localhost:3000/api/adm/:id
export async function deleteUserADM(req, res){
    const {ra} = req.params
    try{
        const[result] = await pool.query(
            'DELETE FROM adm WHERE ra =?',
            [ra]
        )
        if(result.affectedRows === 0){
            return res.status(404).json({error:'Administrador não encontrado!'})
        }
        res.json({message:'Administrador excluído com sucesso'})
    } catch {
        res.status(500).json({error:'Erro ao excluir Administrador'})
    }
}
//Rota do Tipo PUT
//http://localhost:3000/api/adm/:ra
export async function updateUserADM(req, res){
    const {ra} = req.params
    const {name, email, telefone, senha} = req.body
    if(!name || !email || !telefone || !senha){
        return res.status(400).json({error:'Nome, Email, Telefone e Senha são obrigatórios'})
    }
    try{
        const[result] = await pool.query(
            'UPDATE adm SET name =?, email=?, telefone =?, senha =? WHERE ra=?',
            [name, email, telefone, senha, ra]
        )
        if(result.affectedRows === 0){
            return res.status(404).json({error:'usuário não encontrado'})
        }
        const[rows] = await pool.query(
            'SELECT ra, name, email, telefone, senha, created_at FROM adm WHERE ra= ?',
            [ra]
        )
        res.json(rows[0])
    } catch(err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({error:'Email já cadastrado'})
        }
        res.status(500).json({error:'Erro ao atualizar o cadastro de Administrador'})
    }
}
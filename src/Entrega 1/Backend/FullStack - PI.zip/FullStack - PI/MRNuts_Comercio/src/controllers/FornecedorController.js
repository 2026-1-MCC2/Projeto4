import {pool} from '../db.js'

//Listar Todos Fornecedor
export async function getUsersFornecedor(_, res){
    try{
        const [rows] = await pool.query(
            'SELECT idf, name, cnpj, email, senha, created_at FROM fornecedor WHERE idf= ?'
        )
        res.json(rows)
    } catch {
        res.status(500).json({error: 'Erro ao listar users Fornecedor'})
    }
}
//Criar Usuário Fornecedor
export async function createUserFornecedor(req, res){
    const {name, cnpj, email, senha} = req.body
    if(!name || !cnpj || !email || !senha){
        return res.status(400).json({error: 'Nome, CNPJ, Email e Senha são obrigatórios'})
    }
    try{
        const [result] = await pool.query(
            'INSERT INTO fornecedor (name, cnpj, email, senha) VALUES (?,?,?,?)',
            [name, cnpj, email, senha]
        )
        res.status(201).json({idf: result.insertId})
    } catch (err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({error: 'Fornecedor já cadastrado'})
        }
        res.status(500).json({error: 'Erro ao criar Fornecedor'})
    }
}

//Buscar por id fornecedor
//http://localhost:3000/api/fornecedor/:idf
export async function getFornecedorByID(req, res){
    const {idf} = req.params
    try{
        const [rows] = await pool.query(
            'SELECT idf, name, cnpj, email, senha, created_at FROM fornecedor WHERE idf= ?',
            [idf]
        )
        if(rows.length === 0){
            return res.status(404).json({error: 'Fornecedor não encontrado'})
        }
        res.json(rows[0])
    } catch {
        res.status(500).json({error: 'Erro ao Buscar Fornecedor'})
    }
}

//Rota do Tipo DELETE fornecedor
//http://localhost:3000/api/fornecedor/:idf
export async function deleteUserFornecedor(req, res){
    const {idf} = req.params
    try{
        const[result] = await pool.query(
            'DELETE FROM fornecedor WHERE idf =?',
            [idf]
        )
        if(result.affectedRows === 0){
            return res.status(404).json({error:'Fornecedor não encontrado!'})
        }
        res.json({message:'Fornecedor excluído com sucesso'})
    } catch {
        res.status(500).json({error:'Erro ao excluir Fornecedor'})
    }
}
//Rota do Tipo PUT fornecedor
//http://localhost:3000/api/fornecedor/:idf
export async function updateUserFornecedor(req, res){
    const {ra} = req.params
    const {name, cnpj, email, senha} = req.body
    if(!name || !cnpj || !email || !senha){
        return res.status(400).json({error:'Nome, CNPJ, Email e Senha são obrigatórios'})
    }
    try{
        const[result] = await pool.query(
            'UPDATE fornecedor SET name =?, cnpj=?, email =?, senha =? WHERE idf=?',
            [name, cnpj, email, senha, idf]
        )
        if(result.affectedRows === 0){
            return res.status(404).json({error:'Fornecedor não encontrado'})
        }
        const[rows] = await pool.query(
            'SELECT idf, name, cnpj, email, senha, created_at FROM fornecedor WHERE idf= ?',
            [idf]
        )
        res.json(rows[0])
    } catch(err){
        if(err.code === 'ER_DUP_ENTRY'){
            return res.status(409).json({error:'Fornecedor já cadastrado'})
        }
        res.status(500).json({error:'Erro ao atualizar o cadastro de Fornecedor'})
    }
}